#!/bin/bash

##############################################################
# Set Your System and Wordpress Config Preferences
##############################################################

export SYSTEM_USER=bavouchers                # User nginx runs under
export HOME_FOLDER=/home/${SYSTEM_USER}     # system user home folder

# Site info
export SITE_URL=vouchers-uat.hangar51.cloud
export S3_CONFIG_FOLDER="s3://bavouchers-uat-config-cmelgvso"

##########################
# Start the setup and install
##########################

# Create a user for the website to run under (I don't like running as a guessable user)
echo "Creating $SYSTEM_USER user and setting permissions"
useradd $SYSTEM_USER


# Run system updates
dnf update -y

dnf install -y gcc python3-devel
dnf install -y git cronie mariadb105-server nginx python3-pip

# Install Boto3 - reuired to update config and passwords
pip3 install boto3

# Create html folder
echo "Creating HTML folder"
mkdir -p /var/www/
chown -R $SYSTEM_USER:nginx  /var/www

# Move setup files to /var/www
mv /home/ec2-user/update.sh ${HOME_FOLDER}
mv /home/ec2-user/restart.sh ${HOME_FOLDER}
mv /home/ec2-user/onreboot.py ${HOME_FOLDER}
chmod 700 ${HOME_FOLDER}/update.sh
chmod 700 ${HOME_FOLDER}/restart.sh
chmod 700 ${HOME_FOLDER}/onreboot.py
chown -R $SYSTEM_USER ${HOME_FOLDER}/update.sh
chown -R $SYSTEM_USER ${HOME_FOLDER}/restart.sh
chown -R $SYSTEM_USER ${HOME_FOLDER}/onreboot.py

# Download and install ssh config and deploy keys from S3
echo "Downloading ssh config and deploy keys from ${S3_CONFIG_FOLDER}"
mkdir /home/$SYSTEM_USER/.ssh
aws s3 cp ${S3_CONFIG_FOLDER}/bavouchers_ssh_config /home/$SYSTEM_USER/.ssh/config
aws s3 cp ${S3_CONFIG_FOLDER}/bavouchers_github_deploy /home/$SYSTEM_USER/.ssh/github_deploy_rsa
aws s3 cp ${S3_CONFIG_FOLDER}/bavouchers_github_deploy.pub /home/$SYSTEM_USER/.ssh/github_deploy_rsa.pub

# Set permissions
chown -R $SYSTEM_USER /home/$SYSTEM_USER/.ssh
chmod 700 /home/$SYSTEM_USER/.ssh
chmod 600 /home/$SYSTEM_USER/.ssh/*

# Download and extract source code from github
su - $SYSTEM_USER <<'EOF'
echo "Downloading code from github"
cd $HOME_FOLDER

# Add github to known hosts

touch ~/.ssh/known_hosts
if [ ! -n "$(grep "^github.com " ~/.ssh/known_hosts)" ]; then ssh-keyscan github.com >> ~/.ssh/known_hosts; fi;

# Clone the UAT Branch
git clone -b uat git@github.com:IAG-Ent/BAVouchers.git

# install requirements
cd BAVouchers/webapp
pip3 install -r requirements.txt
pip3 install gunicorn

# Create the live config
mkdir -p instance logs uploads
chmod 777 uploads
cp logging.conf.dist logging.conf

EOF

# Create logs folder
mkdir /var/log/bavouchers
chown $SYSTEM_USER:nginx /var/log/bavouchers

# enable cron and setup cronjob
systemctl start crond
systemctl enable crond
echo "0 2 * * * su bavouchers -c '/home/bavouchers/BAVouchers/webapp/runNightly.sh UAT'" > /var/spool/cron/root

# Allow system user to run systemctl
echo "$SYSTEM_USER ALL=NOPASSWD: /usr/bin/systemctl" >> /etc/sudoers

# create gunicorn config file
cat << EOF > ${HOME_FOLDER}/BAVouchers/webapp/bavouchers.gunicorn.py
accesslog = '/var/log/bavouchers/access.log'
errorlog = '/var/log/bavouchers/error.log'
capture_output = True
reload = True
workers = 5
graceful_timeout = 5
EOF

# Configure gunicorn to start up automatically
cat << EOF > /usr/lib/systemd/system/bavouchers.service
[Unit]
Description=Gunicorn instance for bavouchers
After=network.target

[Service]
User=bavouchers
Group=nginx
WorkingDirectory=${HOME_FOLDER}/BAVouchers/webapp
Environment="CONFIG=uat"
ExecStartPre=/bin/bash /home/bavouchers/update.sh
ExecStart=${HOME_FOLDER}/.local/bin/gunicorn -c bavouchers.gunicorn.py -b 0.0.0.0:8080 run:app
Restart=always
RestartSec=5
StartLimitBurst=3

[Install]
WantedBy=multi-user.target
EOF

# Configure logrotate to rotate logs
cat << EOF > /etc/logrotate.d/bavouchers
/var/log/bavouchers/*log {
    daily
    rotate 7
    missingok
    notifempty
    compress
    sharedscripts
    postrotate
    systemctl restart bavouchers
    endscript
}
EOF

# Configure NGINX
cat << EOF > /etc/nginx/nginx.conf
user nginx;
worker_processes auto;
error_log /var/log/nginx/error.log;
pid /run/nginx.pid;
# Load dynamic modules. See /usr/share/nginx/README.dynamic.
include /usr/share/nginx/modules/*.conf;
events {
    worker_connections 1024;
}
http {
    upstream bavouchers {
        server 127.0.0.1:8080;
    }

    log_format  main  '\$remote_addr - \$remote_user [\$time_local] "\$request" '
                      '\$status \$body_bytes_sent "\$http_referer" '
                      '"\$http_user_agent" "\$http_x_forwarded_for"';
    access_log  /var/log/nginx/access.log  main;
    sendfile            on;
    tcp_nopush          on;
    tcp_nodelay         on;
    keepalive_timeout   65;
    types_hash_max_size 2048;
    include             /etc/nginx/mime.types;
    default_type        application/octet-stream;
    # Load modular configuration files from the /etc/nginx/conf.d directory.
    # See http://nginx.org/en/docs/ngx_core_module.html#include
    # for more information.
    include /etc/nginx/conf.d/*.conf;
}
EOF

# Configure NGINX VirtualHost
cat << EOF > /etc/nginx/conf.d/$SITE_URL.conf
server {
    listen 80;

    root   /var/www/html;
    index index.html

    server_name localhost;

    client_max_body_size 20M;

    # Security headers...
    server_tokens off;
    add_header X-Frame-Options SAMEORIGIN always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Strict-Transport-Security "max-age=63072000; includeSubdomains; preload";
    add_header Content-Security-Policy "frame-ancestors 'self'";

    location / {
      try_files \$uri @proxy_to_app;
    }

    location @proxy_to_app {
      proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
      proxy_set_header X-Forwarded-Proto \$http_x_forwarded_proto;
      proxy_set_header Host \$http_host;
      
      # we don't want nginx trying to do something clever with
      # redirects, we set the Host: header above already.
      proxy_redirect off;
      proxy_pass http://bavouchers;
    }
}
EOF


# Start services and set to start on boot

systemctl daemon-reload
systemctl start nginx
systemctl enable nginx

systemctl start bavouchers
systemctl enable bavouchers
