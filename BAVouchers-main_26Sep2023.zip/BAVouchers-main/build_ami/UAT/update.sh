#!/bin/bash
me=$(whoami)
if [ "$me" = "bavouchers" ]; then
   cd /home/bavouchers/BAVouchers || exit
   date > ../last_updated.txt

   # ensure to get origin's data and discard any local change
   git fetch
   git reset origin/uat --hard

   git pull
else
    # Re-run script but as bavouchers user
    su - bavouchers $0
fi
