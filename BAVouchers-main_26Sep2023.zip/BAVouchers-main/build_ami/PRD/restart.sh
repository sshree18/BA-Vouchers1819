#!/bin/bash
sudo systemctl restart bavouchers
