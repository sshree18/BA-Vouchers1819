#!/usr/bin/env python3
import os
import pwd
import grp
import boto3
import sys

def replaceInFile( filename, password ):
    with  open(filename, "rt") as fin:
        #read file contents to string
        data = fin.read()

    #replace all occurrences of the required string
    data = data.replace('##RDS_PASSWORD##', password )


    #open the input file in write mode
    with open(filename, "wt") as fout:
        #overrite the input file with the resulting data
        fout.write(data)


# install the .my.cnf file
def createMyCnfFile( file, db_instance_address, password ):
    with open(file, "wt") as fout:
        fout.write("[client]\n")
        fout.write("host = " + db_instance_address + "\n")
        fout.write("user = admin\n")
        fout.write("password = " + password + "\n")
        fout.write("\n")
        fout.write("[mysql]\n")
        fout.write("database = bavouchers\n")


# install the application.cfg file
def createApplicationCfgFile( file, db_instance_address, password ):

    with open(file, "wt") as fout:
        fout.write('SSM_APP_ROOT = "/BAVouchers/PRD"\n')

        fout.write(f'SQLALCHEMY_DATABASE_URI = "mysql+pymysql://admin:{password}@{db_instance_address}/bavouchers?charset=utf8mb4"\n')
        fout.write(f'SQLALCHEMY_TRACK_MODIFICATIONS = False\n')
        fout.write(f'SQLALCHEMY_ECHO = False\n')
        fout.write(f'WTF_CSRF_TIME_LIMIT=86400 # 1 day expiry\n')
        fout.write(f'FLASK_ENV = "development"\n')

        fout.write(f'WTF_CSRF_ENABLED = True\n')

    os.chmod(file, 0o640)

if __name__ == "__main__":
    secrets_name = sys.argv[1]
    db_instance_name = sys.argv[2]
    client = boto3.client('secretsmanager', 'eu-west-1')

    response = client.get_secret_value( SecretId=secrets_name)

    password = response['SecretString']

    root_mycnf_file = "/root/.my.cnf"
    user_mycnf_file = "/home/bavouchers/.my.cnf"
    user_cfg_file = "/home/bavouchers/BAVouchers/webapp/instance/application.cfg"

    createMyCnfFile( root_mycnf_file, db_instance_name, password )
    createMyCnfFile( "/home/bavouchers/.my.cnf", db_instance_name, password )
    createApplicationCfgFile( "/home/bavouchers/BAVouchers/webapp/instance/application.cfg", db_instance_name, password )

    # Set permissions
    os.chmod(root_mycnf_file, 0o600)
    os.chmod(user_mycnf_file, 0o600)

    # Set ownership
    uid = pwd.getpwnam("bavouchers").pw_uid
    gid = grp.getgrnam("nginx").gr_gid

    os.chown(user_mycnf_file, uid, gid)
    os.chown(user_cfg_file, uid, gid)


