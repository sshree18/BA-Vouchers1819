#!/bin/bash
if [ "$1" == "PRD" ] || [ "$1" == "prd" ]; then
    STACK="PRD"
    PROFILE="bavouchers-prd"
elif [ "$1" == "UAT" ] || [ "$1" == "uat" ]; then
    STACK="UAT"
    PROFILE="bavouchers-uat"
elif [ "$1" == "DEV" ] || [ "$1" == "dev" ]; then
    STACK="DEV"
    PROFILE="digital"
else
    echo "Usage: $0 [PRD|UAT|DEV]"
    exit 1
fi

export AWS_PROFILE=${PROFILE}
shift 1

export AWS_PAGER=""

region_name='eu-west-1' 

while [[ "$#" -gt 0 ]]; do
    case $1 in
        -d|--delete) delete=1
                    ami_id="$2"; shift ;;
        -l|--list) list=1 
                look_for="$2"; shift ;;
        *) echo "Unknown parameter passed: $2"; exit 1 ;;
    esac
    shift
done

if [[ $list -eq 1 ]]; then
filter="*"
filter="?contains(Name, '${look_for}')"
echo "aws ec2 describe-images --owners self --output json --query \"Images[${filter}].{Name:Name,AMI:ImageId,Snapshot:BlockDeviceMappings[0].Ebs.SnapshotId}\""
aws ec2 describe-images --owners self --output json --query "Images[${filter}].{Name:Name,AMI:ImageId,Snapshot:BlockDeviceMappings[0].Ebs.SnapshotId}"
fi

if [[ $delete == 1 ]]; then
    echo DELETE $ami_id

    temp_snapshot_id=''
    my_array=( $(aws ec2 describe-images --image-ids $ami_id --region $region_name  --output text --query "Images[*].BlockDeviceMappings[*].Ebs.SnapshotId") )
    my_array_length=${#my_array[@]} 
    echo "Deregistering AMI: " $ami_id
    aws ec2 deregister-image --image-id $ami_id --region $region_name
    for (( i=0; i<$my_array_length; i++ ))
    do 
        temp_snapshot_id=${my_array[$i]} 
        echo "Deleting Snapshot: " $temp_snapshot_id 
        aws ec2 delete-snapshot --snapshot-id $temp_snapshot_id --region $region_name
    done
fi
