#!/bin/bash

if [ "$1" == "PRD" ] || [ "$1" == "prd" ]; then
    STACK="PRD"
    PROFILE="bavouchers-prd"
elif [ "$1" == "UAT" ] || [ "$1" == "uat" ]; then
    STACK="UAT"
    PROFILE="bavouchers-uat"
elif [ "$1" == "DEV" ] || [ "$1" == "dev" ]; then
    STACK="DEV"
    PROFILE="digital"
else
    echo "Usage: $0 [PRD|UAT|DEV]"
    exit 1
fi

export AWS_PROFILE=${PROFILE}

shift

read -p "Are you sure you wish to create a new ${STACK} AMI (Y/N)? " -n 1 -r
echo    # (optional) move to a new line
if [[ $REPLY =~ ^[Yy]$ ]]
then

    export AWS_PAGER=""

    # packer build -debug ${STACK}/bavouchers_packer_build.pkr.hcl
    packer build ${STACK}/bavouchers_packer_build.pkr.hcl

    echo "DON'T FORGET TO UPDATE THE AMI IN THE Terraform script!"
fi
