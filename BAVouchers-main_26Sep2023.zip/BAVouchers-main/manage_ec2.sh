#!/bin/bash
if [ "$1" == "PRD" ] || [ "$1" == "prd" ]; then
    SERVER_NAME="bavouchers-prd-asg"
    PROFILE="bavouchers-prd"
elif [ "$1" == "UAT" ] || [ "$1" == "uat" ]; then
    SERVER_NAME="bavouchers-uat-asg"
    PROFILE="bavouchers-uat"
elif [ "$1" == "DEV" ] || [ "$1" == "dev" ]; then
    SERVER_NAME="bavouchers-dev-asg"
    PROFILE="digital"
else
    echo "Usage: $0 [prd|uat|dev]"
    exit 1
fi

export AWS_PROFILE=${PROFILE}

echo "Looking up ${SERVER_NAME} Instance....."
instance=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=$SERVER_NAME" "Name=instance-state-name,Values=running" --output text --query 'Reservations[].Instances[].[InstanceId, Tags[?Key==`Name`].Value[]]')
instance_id=$(echo "$instance" | sed '1p;d')
instance_name=$(echo "$instance" | sed '2p;d')

if [[ -z "$instance_id" ]]; then
    echo "No instance found"
    exit 1
fi

echo "found $instance_name - $instance_id"

if [[ "$2" == '-t' ]]
then
    read -p "Are you sure you wish to terminate this instance ? (Y/N)? " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]
    then
        aws ec2 terminate-instances --instance-ids "$instance_id"
    fi
fi
