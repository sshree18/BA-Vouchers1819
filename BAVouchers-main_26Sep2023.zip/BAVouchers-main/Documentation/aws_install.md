
# AWS Setup and Installation

Install on AWS is through a combination of Terraform and Packer (to build the necessary AMI image)

#### Prerequisites:
TO start, ensure terraform and packer are installed.

Current versions:<br>
Terraform - 1.3.9<br>
Packer - 1.8.6

You also need an AWS account setup and the necessary IAM user setup with access keys to enable infrastructure setup, and AWS Session Manager access (to connect to the EC2)

You will need to create an EC2 KeyPair used to create the EC2s (we don't actually use it directly but ensure you back it up somewhere secure).

Finally, you will need to have an SSL certificate registered for your service and available through AWS certificate manager.

For the hangar51.cloud domain see the Hangar51 team who can approve the certificate request otherwise see the CCoE for more info.

#### Initial setup
Within the terraform folder, there are a number of sub folders. These reflect the different environments.

Switch into the required environment

1. Initialise the terraform state buckets<br>
    Switch to step 1 - 1_initial_state_setup<br>
    run: `terraform init`<br>
    then run: `terraform apply -var-file params.tfvars`<br>
    enter `yes` to apply the changes.

2. Setup the VPC, security groups and s3 config bucket<br>
    Switch to step 2 - 2_security_groups<br>
    run: `terraform init`<br>
    then run: `terraform apply -var-file params.tfvars`

    enter `yes` to apply the changes.<br>

    This will create the VPC, and subnets (3 public, and 3 private), and also the S3 config bucket which is where we store GitHub deploy keys and DB Backups<br>

    Make a note of the S3 config bucket - you will need that for **step 4**

3. Create the database<br>
    Switch to step 3 - 3_database
    run: `terraform init`

    then run: `terraform apply -var-file params.tfvars`

    Enter `yes` to apply the changes.<br>

    This will take approx 5-10 minutes to create the database

4. Setup the Deploy keys<br>
    You will need to create the following files
   - a public and private key pair
   follow this guide to create the SSH keypair : https://docs.github.com/en/authentication/connecting-to-github-with-ssh/generating-a-new-ssh-key-and-adding-it-to-the-ssh-agent<br><br>
   These keys should be named:<br>
   `bavouchers_github_deploy` - private key<br>
   `bavouchers_github_deploy.pub` - public key<br><br>
   - A file named `bavouchers_ssh_config` which should contain the following:
        ```
        Host github.com
           IdentityFile ~/.ssh/github_deploy_rsa
        ```
    These files should be uploaded to the S3 config bucket created in **Step 2**

5.  Create the initial base AMI<br>
    In the build_ami folder, you will also see a number of subfolders representing the different environments.  These are the same as those in the terraform folder.

    There are also a couple of scripts that will create an ami or allow you to list and delete existing AMIs (see later information)

    Switch into the relevent environment folder and edit the `referencing_packer_build.pkr` file

    You will need to add in the S3 config bucket in the `source "amazon-ebs" "BAVouchers"` section

    e.g.

    ```
        temporary_iam_instance_profile_policy_document {
            Statement {
                Action   = ["s3:ListBucket", "s3:GetObject"]
                Effect   = "Allow"
                Resource = ["arn:aws:s3:::bavouchers-uat-config-qwertyu", "arn:aws:s3:::bavouchers-uat-config-qwertyu/*"]
        }
    ```

    You may also wish to update the base ami in this section to the latest ARM64 Amazon Linux 2023 AMI (or equivelent recommended image)

    To create the AMI from the build_ami folder simply run the `update_ami.sh` script with the environment name as a parameter.

    This will create the AMI, with the default application setup.

    Monitor the output for any errors.

    Make note of the created AMI id as you will need this for the next step.

6. Create the Application infrastructure<br>
    Back in the terraform folder,
    Switch to step 4 - 4_web_server<br>

    Edit the `params.tf` file and update the `ami_image_id` parameter with the AMI you generated earlier

    Update the `ec2_key_pair` parameter` with the EC2 KeyPair you created (see Prerequisites)

    Update the `ssl_certificate_arn` with the SSL certificate ARN for this instance (see Prerequisites)

    run: `terraform init`<br>
    then run: `terraform apply -var-file params.tfvars`<br>
    enter `yes` to apply the changes.<br><br>

    Make a note of the Application Load Balancer created as you will need that to point the domain at.

At this point, the application infrastructure should be created, and the application deployed BUT it won't work yet because a) the database hasn't actually been setup yet, b) there are some application parameters that need to be set, c) and the necessary domain hasn't been setup

7. To setup the database, you will need to log on the EC2.

    This is because **only** the EC2 can access the Database.

    There is a script in the root of the application - `connect_ec2.sh`<br>
    This uses AWS Session Manager to connect to the EC2.

    Simply run `./connect_ec2.sh <env>` to connect to the EC2.

    The application runs under the bavouchers user so switch over to that user <br>
    `sudo su - bavouchers`

    Switch into the BAVouchers/webapp folder.

    To create the database tables, run:
    `flask db upgrade`

    This will perform the SQLAlchemy migrations and create the db tables.

    Then create the default data including a test admin user<br>
    `python3 -m scripts.init_db`

    Restart the application<br>
    `sudo systemctl restart bavouchers`

8. Create the application configuration<br>
    There is an config_docs folder in the root of the application.<br>

    This contains all the parameters for each environment.<br>
    
    **You SHOULD NOT include values for sensitive parameters!**
    
    You will need to add appropriate values for each parameter.

    There are in the form of AWS CLI commands so you can then run each command in turn to create the parameter.

    Restart the application<br>
    `sudo systemctl restart bavouchers`


9. Point the domain at the Application Load Balancer (ALB)<br>
    If you manage the domain, then within Route53, create an A alias record with your domain name, and the value should be your ALB from step 5.

    If you are using the hangar51.cloud domain then please ask the H51 team to set this up and provide them your ALB details.

You should now be able to access the application through your domain.

The Initial test user setup details are:
username: admin@example.com
password: password

You will be required to change this on first logon and also setup MFA using a Google Authenticator compatible app (e.g. Microsoft Authenticator, 1Password, etc).

