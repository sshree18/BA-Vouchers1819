# Local installation

Running locally is pretty simple and just requires a local MySQL database.,
I typically run this usng Docker and have included the necessayr scripts.

NOTE - this is all tested on a Mac but the instructions should be similar for Windows/Linux

#### Prerequisites:
Docker (or similar)
Python 3.10
Visual Studio Code (for editing and debugging)

#### Installation
- Checkout the code from GitHub to a local folder 
- Switch to the webapp folder
  ```
  cd <path to BAVouchers code>/webapp
  ```

- Create a python virtual environment in the code folder and upgrade pip
  ```
  python -m venv venv
  pip install --upgrade pip
  ```

- Install the dependancies 
  ```
  pip install -r requirements.txt
  ```

- Start the database  
  ```
  docker compose up -d
  ```
  This will download and start a mysql database with a default user of `root` and password `vouchers`

- Create the initial database from the SQLAlchemy migrations
  ```
  CONFIG=localdev flask db upgrade
  ```

- Initialise the database with default data
   ```
   CONFIG=localdev python -m scripts.init_db
   ```
   This will create some default users, and setup some hotels

- Start the application
   ```
      CONFIG=localdev python run.py
   ```
   The CONFIG environment variable specfied which configuration to use - in this case localdev which by default doesn't use AWS for anything and just runs locally.  
   
   It can also use a local OAuth server for testing authentication if desired (you would need to edit the config.py file)

   This will start the server running on port 8080

- Access the application
   The application can be be access from your browser on:
   ```
   https://localhost:8080
   ```

   You will need to use the login:  
   `username: admin@example.com`  
   `password: password`

   You will be required to change your password on first login and also setup Two Factor Authentication using a Google Authenticator complatible app - e.g. Microsoft Authenticator, 1Password, etc


#### Debugging

The application can be debugged using Visual Studio Code

The repo includes a .vscode abd launch.json file.

You need to launch the SVCode instance from the root of the application source code and NOT the webapp folder.

E.g. if you have installed the vscode `code` CLI tool you would run:
```
cd <path to code repository>
code .
```

This will launch VSCode and assuming you have setup the application as above and started the database you can then start a debug session by pressing `F5 (FN + F5 on a Mac)`