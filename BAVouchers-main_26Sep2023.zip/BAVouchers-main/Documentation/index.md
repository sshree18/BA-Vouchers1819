# BAVouchers Documentation

  - [Installation](#installation)
    - [Local installation](local_install.md)
    - [AWS installation](aws_install.md)
  - [Updating](#installation)
    - [Updating AMI](updating_ami.md)
    - [Updating application on AWS](updating_app.md)

