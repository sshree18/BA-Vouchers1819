# BA Vouchers

## Overview

The BA Hotel Vouchers application is a simple web based application to manage and track hotel vouchers issued to disrupted passengers.

It is written in python using the Flask and SQLAlchemy frameworks, and has a MySQL (MariaDB) backend

## Documentation

Details on applications installation, upgrading,etc can be found in the [documentation section](Documentation/index.md)

