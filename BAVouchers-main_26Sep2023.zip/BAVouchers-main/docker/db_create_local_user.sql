grant ALL on vouchers.* to 'admin'@'%' identified by 'vouchers';
