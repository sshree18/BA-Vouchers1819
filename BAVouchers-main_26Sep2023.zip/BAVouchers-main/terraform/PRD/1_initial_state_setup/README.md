# Terraform to setup terraform state S3 bucket and dynamo state lock table

## One-time (per account) setup of terraform state file on S3
1. ensure your .aws/credentials ('default' profile) keys are set to the correct AWS account OR you have an AWS_PROFILE environment set
2. Create the State bucket and Dynamo table
  * Edit xxx.tfvars and set appropriate values
  * terraform init  
  * terraform apply -var-file="xxx.tfvars" 
3. In other terraform files, set values in state.tf set bucket name to dev