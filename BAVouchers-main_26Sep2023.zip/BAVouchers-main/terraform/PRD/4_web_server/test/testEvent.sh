aws events put-events --entries file://event.json
