# Create a secure S3 bucket

## Required Inputs
See variables.tf

## Outputs
See outputs.tf

## Example usage from another terraforms folder

```
module "website_s3_bucket" {
  source = "../modules/s3_secure"

  infra_prefix = "aref_poc"
  name = "jc_test_bucket"
  default_tags = var.default_tags
}
```

run (where xxx is your envionment: poc | dev | tst | uat | prd):
```
terraform plan -var-file="xxx.tfvars" 
terraform apply -var-file="xxx.tfvars" 
```
