#!/bin/bash
if [ "$1" == "prd" ]; then
    SERVER_NAME="bavouchers-prd-asg"
    PROFILE="bavouchers-prd"
elif [ "$1" == "uat" ]; then
    SERVER_NAME="bavouchers-uat-asg"
    PROFILE="bavouchers-uat"
elif [ "$1" == "dev" ]; then
    SERVER_NAME="bavouchers-dev-asg"
    PROFILE="digital"
else
    echo "Usage: $0 [prd|uat]"
    exit 1
fi

export AWS_PROFILE=${PROFILE}

echo "Looking up ${SERVER_NAME} Instance....."
instance_id=$(aws ec2 describe-instances --filters "Name=tag:Name,Values=$SERVER_NAME" "Name=instance-state-name,Values=running" --output text --query 'Reservations[*].Instances[*].InstanceId')

if [[ -z "$instance_id" ]]; then
    echo "No instance found"
    exit 1
fi

echo "Establishing session to instance $instance_id"
aws ssm start-session --target "$instance_id"
