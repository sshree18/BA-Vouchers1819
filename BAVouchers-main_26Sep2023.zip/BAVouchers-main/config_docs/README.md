This file contains the parameters for each enviroment

**YOU SHOULD NOT INCLUDE VALUES FOR ANY SENSITIVE PARAMETERS**

This includes secret keys, client secrets, etc

Some of the values you will need to obtain either through the terraform outputs (from the install), from the AWS console, or from the Authentication teams (for SSO parameters)