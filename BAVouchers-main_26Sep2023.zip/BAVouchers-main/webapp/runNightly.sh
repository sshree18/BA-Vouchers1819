#!/bin/bash
cd /home/bavouchers/BAVouchers/webapp

CONFIG=$1
NIGHTLY_LOG="/var/log/bavouchers/nightly.log"
S3_BUCKET=`aws ssm get-parameter --name "/BAVouchers/${CONFIG}/DB_BACKUP_BUCKET" --with-decryption --region eu-west-1 --output text --query Parameter.Value`

echo "--------------------------------" >> ${NIGHTLY_LOG} 

# write script run time to log
echo "Running nightly script at $(date)" >> ${NIGHTLY_LOG} 2>&1

# Clean up database
echo "Cleaning database" >> ${NIGHTLY_LOG} 2>&1
python3 -m scripts.nightly >> /var/log/bavouchers/runOnSchedule.log 2>&1


