from datetime import datetime
import arrow
from app import create_app

app = create_app()

with app.app_context():

    from app import databaseMgr
    from app import db
    from app.models import Batch, Hotel, Voucher, VoucherArchive, Messages, MessagesArchive


    # Get list of vouchers 
    print( "Archiving yesterdays vouchers")
    vouchers = Voucher.query.all()

    for voucher in vouchers:
        # archive the voucher
        voucher_archive = VoucherArchive(voucher)
        db.session.add(voucher_archive)
        db.session.delete(voucher)
    
    # Clear batches
    batches = Batch.query.all()
    for batch in batches:
        if len(batch.vouchers) == 0:
            db.session.delete(batch)

    # Archive Messages
    messages = Messages.query.all()
    for message in messages:
        # archive the voucher
        message_archive = MessagesArchive(message)
        db.session.add(message_archive)
        db.session.delete(message)

    db.session.commit()

    # Delete from the vouchers archive any voucher created more than 6 months ago
    print( "Clearing up vouchers archive")
    six_months_ago = arrow.utcnow().shift(months=-6).datetime
    VoucherArchive.query.filter(VoucherArchive.created_at < six_months_ago).delete()

    # Delete from the messages archive any message sent more than 6 months ago
    print( "Clearing up messages archive")
    six_months_ago = arrow.utcnow().shift(months=-6).datetime
    MessagesArchive.query.filter(MessagesArchive.sent_at < six_months_ago).delete()

    db.session.commit()

    # Finally reset the number of rooms available for each hotel
    print( "Resetting hotel room allocations")

    hotels = Hotel.query.all()
    for hotel in hotels:
        hotel.rooms_available = hotel.default_room_allocation
    db.session.commit()


