from enum import Enum

class VoucherStatus(Enum):
    ISSUED = "Issued"
    PRINTED = "Printed"
    ACTIVATED = "Activated"
    USED = "Used"

    @classmethod
    def list(cls):
        return list(map(lambda c: c.value, cls))


class RolesEnum(Enum):
    RoomManager = "room-manager"
    VoucherManager = "voucher-manager"
    DashboardAdmin = "dashboard-admin"
    VoucherActivator = "voucher-activator"
    VoucherConsumer = "voucher-consumer"
    SystemAdmin = "system-admin" 

RoomManager = str(RolesEnum.RoomManager.value)
VoucherManager = str(RolesEnum.VoucherManager.value)
DashboardAdmin = str(RolesEnum.DashboardAdmin.value)
VoucherActivator = str(RolesEnum.VoucherActivator.value)
VoucherConsumer = str(RolesEnum.VoucherConsumer.value)
SystemAdmin = str(RolesEnum.SystemAdmin.value)


# BA User username
BA_USER = "BA USER"

# BAU - Business As Usual
# DIS - Disruption
class IssueType(Enum):
    BAU = "BAU"
    DIS = "DIS"

