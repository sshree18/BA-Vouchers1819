import boto3
import json
from flask import request
from flask import current_app as app

from app import utils
from app.utils import logger

ssm = boto3.client('ssm', region_name='eu-west-1')
eventbus = boto3.client('events', region_name='eu-west-1')

# ssmRoot = app.config['SSM_APP_ROOT']

def get_settings( path = None ):
    if path == None:
        path = app.config['SSM_APP_ROOT']

    ret = {} 
    resp = ssm.get_parameters_by_path( Path=path, WithDecryption=True )
    while resp != None:
        start = len( path ) + 1
        for x in resp['Parameters']: 
            ret[x['Name'][start:]] = x["Value"]

        token = resp.get('NextToken', None)
        if token == None:
            resp = None
        else:
            resp = ssm.get_parameters_by_path( Path=path, WithDecryption=True, NextToken=token )
    return ret


def sendEmail( template, subject, params, to_list, send_from ):
    """
    Send an email.
    template - the name of the template to use
    subject - the subject of the email
    params - a dictionary of parameters to pass to the template
    to - an array of email addresses to send to
    """

    #logger.debug( "*** Sending mail to " + to )
    # add any system template params - url bases, etc
    host_url = app.config.get( "APP_URL", None)
    if host_url == None:
        host_url = request.host_url
        if host_url[-1] == '/':
            host_url = host_url[:-1]

    # force http to https in host_url
    if "localhost" not in host_url and host_url.startswith( "http://"):
        host_url = host_url.replace( "http://", "https://" )

    params["url_base"] = host_url
    params["app_name"] = app.config["APP_NAME"]


    # Get the queue
    email_queue = app.config["EMAIL_QUEUE"]
    #logger.debug( f"getting {email_queue}")
    queue = sqs.get_queue_by_name(QueueName=email_queue)

    source_email = send_from

    # Default to force sending to the email in app config
    # Only allow Yes to send out test emails and default to no
    send_to = []
    if app.config.get("SEND_OUT_LIVE_MAILS", "No") == "Yes":
        send_to = to_list
    else:
        test_email = app.config["TEST_EMAIL_SENDING_TO"]
        addedTestEmail = False
        for to in to_list:
            if to.endswith("@ba.com") or to.endswith("@iairgroup.com") or to.endswith("@iaggbs.com"):
                send_to.append(to)
            elif addedTestEmail == False:
                send_to.append(test_email)
                addedTestEmail = True

    detail = {"email_destinations": send_to,
            "email_subject": subject,
            "email_template": template,
            "template_data": params,
            "source_email_address": source_email,
            "email_queue_url": queue.url
        }

    response = sendEvent("send_email", detail)
    #print( response )
    

def sendEvent( event_type, detail, event_source="bavouchers" ):
    response = eventbus.put_events(
        Entries=[
            {
                "Source": event_source,
                "DetailType": event_type,
                "Detail": json.dumps(detail),
                "EventBusName": app.config["EVENT_BUS"]
            },
        ]
    )
    return response

def addAuditEntry( source_user, event, details, parent_event_id="None" ):
    clientIP = utils.getClientIP()
    
    if source_user and source_user.is_authenticated:
        initiator = source_user.login_id
        try:
            detail = {
                    "action": event,
                    "initiator": source_user.login_id if source_user else 'System',
                    "detail" : details,
                    "parent_event_id" : parent_event_id if parent_event_id != None else "None",
                    "sensitive_data" : {"usersIP": clientIP},
            }

            response = sendEvent("audit_message", detail, "bavouchers.audit")
            # print('audit entry: ', response)   
        except Exception as e:
            logger.error( f"Error adding audit entry to {app.config['EVENT_BUS']} {detail}: {e}" )
