from enum import Enum
from datetime import datetime, timedelta, timezone
import arrow

from flask_login import UserMixin, current_user
from flask import redirect, url_for
from werkzeug.security import generate_password_hash, check_password_hash
from sqlalchemy.sql import expression, func

from app import db
from app import constants


class IPWhitelistItem(db.Model):
    __tablename__ = "ip_whitelist"

    id = db.Column(db.Integer, primary_key=True)
    cidr = db.Column(db.String(25), nullable=False, unique=True)
    description = db.Column(db.String(100), nullable=False, unique=True)
    created_at = db.Column(db.DateTime, nullable=False, server_default=func.now())
    updated_at = db.Column(db.DateTime, nullable=False, server_default=func.now(), onupdate=func.now())

    def __repr__(self):
        return f"<IPWhitelist {self.cidr}>"

    def __str__(self):
        return self.cidr

class Role(db.Model):
    __tablename__ = "roles"
    role_id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.Text, nullable=False)

    def __repr__(self):
        return f"Role {self.name}"


users_roles = db.Table('users_x_roles',
    db.Column('user_id', db.Integer, db.ForeignKey('users.user_id', ondelete="cascade"), primary_key=True),
    db.Column('role_id', db.Integer, db.ForeignKey('roles.role_id', ondelete="cascade"), primary_key=True),
    db.Column('assigned_at', db.DateTime, nullable=False, server_default=db.func.now())
)

class User(UserMixin, db.Model):
    __tablename__ = "users"

    user_id = db.Column(db.Integer, primary_key=True)
    session_id = db.Column(db.String(100), nullable=True)

    login_id = db.Column(db.String(100), nullable=False, unique=True)
    name = db.Column(db.String(100))
    password_hash = db.Column(db.String(128), nullable=True)
    otp_secret = db.Column(db.String(16))
    reset_password_token = db.Column(db.String(32), nullable=True)
    reset_password_expiry = db.Column(db.DateTime, nullable=True)
    password_attempts = db.Column(db.Integer, nullable=True, server_default='0')
    otp_attempts = db.Column(db.Integer, nullable=True, server_default='0')
    locked = db.Column(db.Boolean, nullable=False, server_default=expression.false())
    change_password = db.Column(db.Boolean, nullable=False, server_default=expression.true())
    created_at = db.Column(db.DateTime, nullable=False, server_default=db.func.now())
    last_logged_in = db.Column(db.DateTime, nullable=True)
    last_read_message = db.Column(db.DateTime, nullable=True)
    api_key = db.Column(db.String(100), nullable=True)
    api_key_issued_at = db.Column(db.DateTime, nullable=True)
    password_expires = db.Column(db.Date, nullable=True)

    roles = db.relationship('Role', secondary=users_roles,
                            backref=db.backref('users'),
                            cascade="all, delete",
                            passive_deletes=True,
                            )

    def get_id(self):
        return self.user_id

    def __repr__(self):
        return f"<User {self.login_id}>"

    @property
    def password(self):
        raise AttributeError('password is not a readable attribute')

    @password.setter
    def password(self, password):
        self.password_hash = generate_password_hash(password)

    def isBAUser(self):
        return self.name == constants.BA_USER

    def verify_password(self, password):
        if self.password_hash == None:
            return False
        return check_password_hash(self.password_hash, password)

    def has_role( self, role ):
        for role_ in self.roles:
            if role_.name == role:
                return True
        return False

    def has_any_roles( self, roles ):
        for role_ in self.roles:
            if role_.name in roles:
                return True
        return False

    def logout( self):
        return redirect(url_for('auth.logout'))

    def redirectToHome( self):
        return redirect(url_for('admin.index'))
    
class Hotel(db.Model):
    __tablename__ = "hotel"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=True)
    address = db.Column(db.String(300), nullable=True)
    display_order = db.Column(db.Integer, nullable=False, server_default='0')

    checkin_time = db.Column(db.String(10), nullable=True, server_default='14:00')
    checkout_time = db.Column(db.String(10), nullable=True, server_default='12:00')
    breakfast_times = db.Column(db.String(20), nullable=True, server_default='06:30 - 10:30')
    dinner_times = db.Column(db.String(20), nullable=True, server_default='18:30 - 22:30')
    additional_info = db.Column(db.String(80), nullable=True)

    default_room_allocation = db.Column(db.Integer, nullable=False, server_default='50')
    rooms_available = db.Column(db.Integer, nullable=False, server_default='0')

    # The safety_stack percentage - i.e. we keep 10% of expired allocated rooms
    bau_safetystock_rate = db.Column(db.Integer, nullable=False, server_default='10')
    dis_safetystock_rate = db.Column(db.Integer, nullable=False, server_default='20')

    bau_printed_expiry = db.Column(db.Integer, nullable=False, server_default='1')
    dis_printed_expiry = db.Column(db.Integer, nullable=False, server_default='1')

    bau_activated_expiry = db.Column(db.Integer, nullable=False, server_default='4')
    dis_activated_expiry = db.Column(db.Integer, nullable=False, server_default='4')

    batch = db.relationship('Batch', backref='hotel', lazy=True, cascade="all, delete-orphan")
    vouchers = db.relationship('Voucher', backref='hotel', lazy=True, cascade="all, delete-orphan")

class Batch(db.Model):
    __tablename__ = "batch"
    id = db.Column(db.Integer, primary_key=True)
    description = db.Column(db.String(50), nullable=True, )

    hotel_id = db.Column(db.Integer, db.ForeignKey('hotel.id', ondelete="cascade"))

    created_by = db.Column(db.String(100), nullable=False, )
    created_at = db.Column(db.DateTime, nullable=False, server_default=func.now())

    vouchers = db.relationship('Voucher', backref='batch', lazy=True, cascade="all, delete-orphan")
    has_been_printed = db.Column(db.Boolean, nullable=False, server_default=expression.false())

    def __repr__(self):
        return f"<Batch {self.batch_id}>"
    
    def as_dict(self):
       return {c.name: getattr(self, c.name) for c in self.__table__.columns}


class Voucher(db.Model):
    __tablename__ = "vouchers"
    voucher_id = db.Column(db.String(50), primary_key=True)

    batch_id = db.Column(db.Integer, db.ForeignKey('batch.id', ondelete="cascade"), nullable=False)
    hotel_id = db.Column(db.Integer, db.ForeignKey('hotel.id', ondelete="cascade"), nullable=False)

    status = db.Column(db.String(32), nullable=False)
    stage_expiry = db.Column(db.DateTime, nullable=False)
    issue_type = db.Column(db.String(5), nullable=False, server_default='BAU')

    issued_by = db.Column(db.String(100), nullable=False )
    issued_at = db.Column(db.DateTime, nullable=False)
    printed_by = db.Column(db.String(100), nullable=True )
    printed_at = db.Column(db.DateTime, nullable=True)
    activated_by = db.Column(db.String(100), nullable=True )
    activated_at = db.Column(db.DateTime, nullable=True)
    used_by = db.Column(db.String(100), nullable=True )
    used_at = db.Column(db.DateTime, nullable=True)

    created_at = db.Column(db.DateTime, nullable=False, server_default=func.now())
    
    def has_expired(self):
        return self.stage_expiry < datetime.utcnow()
    
    def issued(self, issue_type):
        midnight_tomorrow = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0) + timedelta(days=1)

        self.status = constants.VoucherStatus.ISSUED.value
        self.issue_type = issue_type
        self.stage_expiry = midnight_tomorrow
        self.issued_by = current_user.login_id
        self.issued_at = datetime.utcnow()


    def printed(self):
        if self.status == constants.VoucherStatus.ISSUED.value and not self.has_expired():
            self.status = constants.VoucherStatus.PRINTED.value

            if self.issue_type == constants.IssueType.BAU.value:
                self.stage_expiry = datetime.utcnow() + timedelta(hours=self.hotel.bau_printed_expiry)
            else:
                self.stage_expiry = datetime.utcnow() + timedelta(hours=self.hotel.dis_printed_expiry)

            self.printed_by = current_user.login_id
            self.printed_at = datetime.utcnow()

    def activate(self):
        if self.status == constants.VoucherStatus.ISSUED.value or self.status == constants.VoucherStatus.PRINTED.value and not self.has_expired():
            self.status = constants.VoucherStatus.ACTIVATED.value

            # Expiry time is either 4 hours from the checkin time (if activated before the checkin time)
            # OR 4 hours from the current time (if activated after the checkin time)
            checkinTime = self.hotel.checkin_time
            checkinHour = int(checkinTime.split(":")[0])
            checkinMins = int(checkinTime.split(":")[1])

            # Get current time in hours
            currentHour = datetime.now().hour
            currentMins = datetime.now().minute

            if currentHour < checkinHour or (currentHour == checkinHour and currentMins < checkinMins):
                expiryHour = checkinHour
                expiryMins = checkinMins
            else:
                expiryHour = currentHour
                expiryMins = currentMins

            # we ned to get current time in London as the checkin times are local time NOT GMT!
            # so our offset is local relative and then converted to GMT later
            expiryTime = arrow.now('Europe/London') 
            if self.issue_type == constants.IssueType.BAU.value:
                expiryHour += self.hotel.bau_activated_expiry
            else:
                expiryHour += self.hotel.dis_activated_expiry

            days = 0
            if expiryHour > 23:
                days = 1
                expiryHour -= 24
                
            expiryTime = expiryTime.replace(hour=expiryHour, minute=expiryMins, second=0, microsecond=0)
            expiryTime = expiryTime.shift(days=days)

            self.stage_expiry = expiryTime.datetime.astimezone(timezone.utc)

            self.activated_by = current_user.login_id
            self.activated_at = datetime.utcnow()

    def use(self):
        midnight_tomorrow = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0) + timedelta(days=1)
        self.status = constants.VoucherStatus.USED.value
        self.stage_expiry = midnight_tomorrow
        self.used_by = current_user.login_id
        self.used_at = datetime.utcnow()

    def expire(self, type):
        if not self.has_expired():
            if type == "issued":
                if self.status == constants.VoucherStatus.ISSUED.value or self.status == constants.VoucherStatus.PRINTED.value:
                    self.stage_expiry = datetime.utcnow()
            if type == "activated":
                if self.status == constants.VoucherStatus.ACTIVATED.value:
                    self.stage_expiry = datetime.utcnow()

    def __repr__(self):
        return f"Voucher {self.voucher_id}"

    def as_dict(self):
       return {c.name: getattr(self, c.name) for c in self.__table__.columns}

class Messages(db.Model):
    __tablename__ = "messages"
    message_id = db.Column(db.Integer, primary_key=True)

    sent_by = db.Column(db.String(100), nullable=False)

    message = db.Column(db.String(300), nullable=False)
    is_read = db.Column(db.Boolean, nullable=True, server_default=expression.false())
    sent_at = db.Column(db.DateTime, server_default=func.now())
    read_at = db.Column(db.DateTime, nullable=True)

class MessagesArchive(db.Model):
    __tablename__ = "messages_archive"
    id = db.Column(db.Integer, primary_key=True)

    message_id = db.Column(db.Integer)

    sent_by = db.Column(db.String(100), nullable=False)

    message = db.Column(db.String(300), nullable=False)
    is_read = db.Column(db.Boolean, nullable=True)
    sent_at = db.Column(db.DateTime, nullable=False)
    read_at = db.Column(db.DateTime, nullable=True)

    def __init__(self, message):
        self.message_id = message.message_id
        self.sent_by = message.sent_by
        self.message = message.message
        self.is_read = message.is_read
        self.sent_at = message.sent_at
        self.read_at = message.read_at


class VoucherArchive(db.Model):
    __tablename__ = "vouchers_archive"
    id = db.Column(db.Integer, primary_key=True)

    voucher_id = db.Column(db.String(50))

    hotel_name = db.Column(db.String(100), nullable=True)
    batch_id = db.Column(db.Integer, nullable=False)

    status = db.Column(db.String(32), nullable=False)
    stage_expiry = db.Column(db.DateTime, nullable=False)
    issue_type = db.Column(db.String(5), nullable=False, server_default='BAU')

    issued_by = db.Column(db.String(100), nullable=False )
    issued_at = db.Column(db.DateTime, nullable=False)
    printed_by = db.Column(db.String(100), nullable=True )
    printed_at = db.Column(db.DateTime, nullable=True)
    activated_by = db.Column(db.String(100), nullable=True )
    activated_at = db.Column(db.DateTime, nullable=True)
    used_by = db.Column(db.String(100), nullable=True )
    used_at = db.Column(db.DateTime, nullable=True)

    created_at = db.Column(db.DateTime, nullable=False, server_default=func.now())
    
    def __init__(self, voucher):
        self.voucher_id = voucher.voucher_id
        self.hotel_name = voucher.hotel.name
        self.batch_id = voucher.batch_id
        self.status = voucher.status
        self.stage_expiry = voucher.stage_expiry
        self.issue_type = voucher.issue_type
        self.issued_by = voucher.issued_by
        self.issued_at = voucher.issued_at
        self.printed_by = voucher.printed_by
        self.printed_at = voucher.printed_at
        self.activated_by = voucher.activated_by
        self.activated_at = voucher.activated_at
        self.used_by = voucher.used_by
        self.used_at = voucher.used_at
        self.created_at = voucher.created_at
