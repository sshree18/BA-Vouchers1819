import boto3

ssm = boto3.client('ssm', region_name='eu-west-1')


def get_settings(path):

    ret = {}
    resp = ssm.get_parameters_by_path(Path=path, WithDecryption=True)
    while resp is not None:
        start = len(path) + 1
        for x in resp['Parameters']:
            ret[x['Name'][start:]] = x["Value"]

        token = resp.get('NextToken', None)
        if token is None:
            resp = None
        else:
            resp = ssm.get_parameters_by_path(Path=path, WithDecryption=True, NextToken=token)
    return ret

