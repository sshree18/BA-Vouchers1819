from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, BooleanField
from wtforms.validators import InputRequired, Length, EqualTo

class ChangePasswordForm(FlaskForm):
    """Change password form."""
    current_password = PasswordField('Current Password', validators=[InputRequired()], render_kw={"placeholder": "Current password"})
    password = PasswordField('Password', validators=[InputRequired()], render_kw={"placeholder": "New password"})
    password_again = PasswordField('Password again', validators=[InputRequired(), EqualTo('password')], render_kw={"placeholder": "Confirm new password"})
    submit = SubmitField('Submit')

class RequestResetPasswordForm(FlaskForm):
    """Reset Password form."""
    login_id = StringField('Please enter your login id address', validators=[InputRequired(), Length(1, 100)], render_kw={"placeholder": "Your login id"})
    submit = SubmitField('Submit')

class ResetPasswordForm(FlaskForm):
    """Reset Password form."""
    password = PasswordField('Password', validators=[InputRequired()], render_kw={"placeholder": "New password"})
    password_again = PasswordField('Password again', validators=[InputRequired(), EqualTo('password')], render_kw={"placeholder": "Confirm new password"})
    submit = SubmitField('Submit')

class SetupMFAForm(FlaskForm):
    token = StringField('Token', validators=[InputRequired(), Length(6, 6)], render_kw={"placeholder": "MFA Code", "type" : "number"})
    submit = SubmitField('Verify MFA Code')

class LoginForm(FlaskForm):
    """Login form."""
    login_id = StringField('login_id', validators=[InputRequired(), Length(1, 100)])
    password = PasswordField('Password', validators=[InputRequired()])
    submit = SubmitField('Login')

class TwoFactorForm(FlaskForm):
    """Ask Two Factor form."""
    token = StringField('Token', validators=[InputRequired(), Length(6, 6)], render_kw={"placeholder": "MFA Code", "type" : "number"})
    submit = SubmitField('Enter Code')
