import logging

from .configuration import Configuration
from .auth import AuthClient

__version__ = '0.0.0'

logging.getLogger('ping_oauth_lib').addHandler(logging.NullHandler())
