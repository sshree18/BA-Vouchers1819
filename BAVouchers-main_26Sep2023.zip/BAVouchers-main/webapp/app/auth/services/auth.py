import json
import logging
from urllib.parse import urljoin, quote_plus
from functools import wraps, partial
import jwt
import requests
from oauthlib.common import generate_nonce

from requests_oauthlib import OAuth2Session
from flask import abort, redirect, request, session, flash, redirect, url_for
from oauthlib.oauth2 import WebApplicationClient, BackendApplicationClient, MobileApplicationClient

from .configuration import Configuration
from app import utils

# OpenID Connect/OAuth 2 protocol related parameters
TOKEN_TYPE = 'token_type'
SCOPE = 'scope'
EXPIRES_IN = 'expires_in'
CODE = 'code'
STATE = 'state'
NONCE = 'nonce'
ID_TOKEN = 'id_token'

#  Authorization grant types by which a client application obtains an authorization grant in the form of an access token.
CLIENT_CREDENTIALS_GRANT_TYPE = 'client_credentials'
IMPLICIT_GRANT_TYPE = 'implicit'

# Configuration parameters from config.cfg
RESPONSE_TYPE_CONFIG = 'RESPONSE_TYPE'
SECRET_KEY_CONFIG = 'SECRET_KEY'
SCOPE_CONFIG = 'SCOPE'

# Application internal parameters
AUTH_STATE_KEY = 'oauth_state'
AUTH_NONCE_KEY = 'oauth_nonce'
AUTH_TOKEN_KEY = 'oauth_token'
USER_DETAILS = 'user_details'
RESPONSE_URL = 'responseUrl'


class AuthClient(Configuration):

    def __init__(self, app=None):
        if app:
            self.init_app(app)

    def init_app( self, app ):
        Configuration.__init__(self, app.config)

        self.config = app.config
        setupManually = True
        if self.autodiscover_uri != None:
            try:
                logging.debug( f"Trying to autodiscover using {self.autodiscover_uri}")
                self.autodiscover()
                setupManually = False
                logging.debug( f"Successfully autodiscovered")
            except Exception as e:
                logging.debug( f"Error autodiscovering - {e}")
                setupManually = True

        if setupManually:
            logging.debug( "Setting up auth manually!")
            self.issuer = f'{self.authentication_uri}openid'
            self.oauth_url = f'{self.issuer}/authorize'
            self.oauth_token_url = f'{self.issuer}/token'
            self.signOff_url = f'{self.issuer}/end-session'
            self.user_info_url = f'{self.issuer}/userinfo'
            self.jwks_url = f'{self.issuer}/jwks'
    
    def login_required(self, view_func=None):
        if view_func is None:
            return partial(self.login_required)

        @wraps(view_func)
        def view_wrapper(*args, **kwargs):
            if self.is_authenticated():
                return view_func(*args, **kwargs)
            oauth_session = self.get_oauth_session()
            return self.oauth_redirect(oauth_session)

        return view_wrapper

    def require_role(self, allowed_roles):
        """ Decorator passes on specific list of usernames. """

        def _outer_wrapper(f):

            def _wrapper(*args, **kwargs):

                user = self.has_valid_role( allowed_roles )
                if user:
                    return f(user, *args, **kwargs)
                
                flash( "This resource is protected and requires user authentication. Please login firstly." )
                return redirect(url_for('auth.home'))
                # return UnauthorizedError('Not Authorized')
            
            _wrapper.__name__ = f.__name__
            return _wrapper
        
        return _outer_wrapper


    def autodiscover(self):
        """
        Autodiscover the OpenID Connect configuration from the discovery endpoint
        :return:
        """
        try:
            user_agent = {'User-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.1 Safari/605.1.15'}
            response = requests.get(self.autodiscover_uri, headers = user_agent)
            response.raise_for_status()
            self.issuer = response.json().get('issuer')
            self.oauth_url = response.json().get('authorization_endpoint')
            self.oauth_token_url = response.json().get('token_endpoint')
            self.signOff_url = response.json().get('end_session_endpoint')
            if self.signOff_url == None:
                self.signOff_url = response.json().get('ping_end_session_endpoint')
            self.user_info_url = response.json().get('userinfo_endpoint')
            self.jwks_url = response.json().get('jwks_uri')
        except requests.exceptions.RequestException as e:
            logging.error('Error while autodiscovering the OpenID Connect configuration: {}'.format(e))

    def oauth_redirect(self, oauth_session):
        """
        redirect to the oauth url with setting the anti-forgery 'state' token in the session
        :param oauth_session: instance of OAuth 2 extension to :class:`requests_oauthlib.OAuth2Session`.
        """
        nonce = generate_nonce()
        authorization_url, state = oauth_session.authorization_url(url=self.oauth_url, prompt=self.prompt,
                                                                   max_age=self.max_age, nonce=nonce)
        session[AUTH_STATE_KEY] = state
        session[AUTH_NONCE_KEY] = nonce
        session.modified = True
        return redirect(authorization_url)

    def get_oauth_token(self, verify_state=True):

        """
        return an oauth token for the user - expects the request it gets back from the
        oauth provider to have a "code" parameter and a `state` parameter
        if the state from the params (`stated_state`) doesn't match the `oauth_state`
        (`known_state`) stored in the session, we'll 403 af outta here
        abort with a 403 if anything goes wrong when fetching the token from the oauth
        provider
        :param verify_state:
        :return:
        """
        oauth_session = self.get_oauth_session()

        if self.grant_type and self.grant_type == IMPLICIT_GRANT_TYPE:
            return self.get_token_from_implicit_flow(oauth_session)

        code = request.args.get(CODE)
        stated_state = request.args.get(STATE)
        known_state = session.get(AUTH_STATE_KEY)

        if verify_state and (not known_state or not stated_state or stated_state != known_state):
            # the requests_oauthlib library won't handle this check for us unless
            # we provide the known_state to the OAuth2Session constructor *and* use the
            # authorization_response kwarg (which is a url string) with `fetch_token`
            # we're not doing that since authorization_response must have https scheme
            # or requests_oauthlib barfs out
            abort(403)

        return oauth_session.fetch_token(self.oauth_token_url, client_secret=self.client_secret, code=code,
                                         include_client_id=self.include_client_id)

    def get_oauth_session(self):
        known_state = session.get(AUTH_STATE_KEY)
        redirect_url = urljoin(request.url_root, self.redirect_path)

        if self.grant_type and self.grant_type == CLIENT_CREDENTIALS_GRANT_TYPE:
            client = BackendApplicationClient(client_id=self.client_id)
            oauth_session = OAuth2Session(client=client, token=session.get(AUTH_TOKEN_KEY))

        elif self.grant_type and self.grant_type == IMPLICIT_GRANT_TYPE:
            client = MobileApplicationClient(self.client_id)
            client.response_type = self.config.get(RESPONSE_TYPE_CONFIG)
            oauth_session = OAuth2Session(client_id=self.client_id,
                                          state=known_state,
                                          scope=self.config.get(SCOPE_CONFIG).split(),
                                          redirect_uri=redirect_url,
                                          client=client,
                                          token=session.get(AUTH_TOKEN_KEY))
        else:
            client = WebApplicationClient(self.client_id)
            oauth_session = OAuth2Session(client_id=self.client_id,
                                          state=known_state,
                                          scope=self.config.get(SCOPE_CONFIG).split(),
                                          redirect_uri=redirect_url,
                                          client=client,
                                          token=session.get(AUTH_TOKEN_KEY))

        oauth_session.headers.update({'User-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.1 Safari/605.1.15'})

        return oauth_session

    def get_id_token(self):
        # Reading the user id token claimset without performing validation of the signature or any of the registered claim
        # names for getting a "sub" claim (the user ID)
        return jwt.decode(session.get(AUTH_TOKEN_KEY).get('access_token'), self.config.get(SECRET_KEY_CONFIG),
                          verify=False)

    def get_logout_url(self):
        """
        :return:  the endpoint to initiate end user logout if user is authenticated and has a valid ID token that indicates the identity of the user
        """
        if self.is_authenticated() and session.get(AUTH_TOKEN_KEY) and session.get(AUTH_TOKEN_KEY).get(ID_TOKEN):
            logout_url = f'{self.signOff_url}?LogoutType=AsyncOnly'
            # logout_url = '{}?id_token_hint={}'.format(self.signOff_url, session.get(
                # AUTH_TOKEN_KEY).get(ID_TOKEN))
            if self.logout_uri:
                logout_url += f'&TargetResource={self.logout_uri}'
            return logout_url
        return None

    def get_user_details(self):
        if self.is_authenticated():
            if not session.get(USER_DETAILS):
                oauth_session = self.get_oauth_session()
                user_details = oauth_session.get(self.user_info_url)
                user_details.raise_for_status()

                user_info = user_details.json()

                # if role is not a list, make it one
                if not isinstance(user_info.get("role"), list):
                    user_info["role"] = [user_info.get("role")]
                session[USER_DETAILS] = user_info
            return session[USER_DETAILS]
        return None

    def callback(self, view_func=None, **options):
        # If called without method, we've been called with optional arguments.
        # We return a decorator with the optional arguments filled in.
        # Next time round we'll be decorating method.
        if view_func is None:
            return partial(self.callback, **options)

        @wraps(view_func)
        def view_wrapper(*args, **kwargs):
            if not self.is_authenticated():
                token = self.get_oauth_token()
                if token is not None:
                    self.validate_token(token[ID_TOKEN])
                    session[AUTH_TOKEN_KEY] = token

                    # generate session id
                    session_id = utils.generate_session_id()
                    session["session_id"] = session_id

                    # force our changes to be recognized
                    session.modified = True
            else:
                logging.info('Application was already logged in')
            return view_func(*args, **kwargs)

        return view_wrapper


    def has_valid_role( self, allowed_roles ):
        user = self.get_user_details()

        found = False
        if user != None:
            for role in user.get('role', []):
                if role in allowed_roles:
                    found = True
                    break

        return user if found else None

    def token_required(self, view_func=None):
        if view_func is None:
            return partial(self.token_required)

        @wraps(view_func)
        def view_wrapper(*args, **kwargs):
            if not self.is_authenticated():
                flash( "This resource is protected and requires user authentication. Please login first." )
                return redirect(url_for('auth.index'))
            else:
                logging.info('Application has a token already.')
            return view_func(*args, **kwargs)

        return view_wrapper


    def validate_token(self, token, verify_nonce=True):
        """
        Validate JWT token
        :param token: JWT token
        :param verify_nonce:
        :return:
        """

        id_token_parts = token.split('.')
        if len(id_token_parts) < 3:
            abort(403, 'Invalid token: unable to split the token content.')

        keys = {}
        # print( f"Available keys - {self.get_jwk()['keys']}")
        for k in self.get_jwk()['keys']:
            keyId = k['kid']
            try:
                key = jwt.algorithms.RSAAlgorithm.from_jwk(json.dumps(k))
                keys[keyId] = key
            except Exception as e:
                # print( f"Got exception extracting RSA key for kid {keyId} - {e}")
                try:
                    key = jwt.algorithms.ECAlgorithm.from_jwk(json.dumps(k))
                    keys[keyId] = key
                except Exception as e:
                    print( f"Got exception extracting key for kid {keyId} (not RSA or ECA) - {e}")
                    continue

        # keys = {k['kid']: jwt.algorithms.RSAAlgorithm.from_jwk(json.dumps(k)) for k in self.get_jwk()['keys']}
        unverified_header = jwt.get_unverified_header(token)
        key_id = unverified_header['kid']
        algorithm = unverified_header['alg']

        # print( f"looking for key  - {key_id}")
        # print( f"have keys - {keys}")
        public_key = keys[key_id]
        # Check and raise an error if the token verification/validation has some errors(i.e is expired, invalid audience).
        decoded_token = jwt.decode(token, public_key, algorithms=algorithm,
                                   issuer=self.issuer, audience=self.client_id,
                                   require_exp=True, require_iat=True)

        known_nonce = session.get(AUTH_NONCE_KEY)
        stated_nonce = decoded_token[NONCE]
        if verify_nonce and (not known_nonce or not stated_nonce or stated_nonce != known_nonce):
            abort(403, "Invalid nonce value. ")

        return decoded_token

    def get_jwk(self):
        """Get all signing keys that can be used to validate JWT signatures.
        :return: JSON Web Key Set [JWK] document
        """

        user_agent = {'User-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.1 Safari/605.1.15'}
        response = requests.get(self.jwks_url, headers = user_agent)
        if response.status_code != 200:
            logging.error('There is no JSON Web Key Set document.')
        response.raise_for_status()
        return response.json()

    @staticmethod
    def is_authenticated():
        return session.get(AUTH_TOKEN_KEY)

    @staticmethod
    def get_token_from_implicit_flow(oauth_session):
        if RESPONSE_URL in request.form:
            stated_state = request.form.get(STATE)
            known_state = session.get(AUTH_STATE_KEY)

            if not known_state or not stated_state or stated_state != known_state:
                abort(403)

            # The full URL of the redirect back to
            url = '{}&expires_in={}&state={}&token_type={}&id_token={}&scope={}'.format(request.form.get(RESPONSE_URL),
                                                                                        request.form.get(EXPIRES_IN),
                                                                                        request.form.get(STATE),
                                                                                        request.form.get(TOKEN_TYPE),
                                                                                        request.form.get(ID_TOKEN),
                                                                                        quote_plus(request.form.get(SCOPE, '')))
            return oauth_session.token_from_fragment(url)
