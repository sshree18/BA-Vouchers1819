import os
import base64
import arrow
import math
import onetimepass
import secrets
import string

from app import db
from app import userUtils
from app.models import User, Role
from app import constants

def getUserById(user_id):
    user = User.query.filter_by(user_id=user_id).first()
    return user

def to_standard_groupname(cd_group_name):
    group_name_list = cd_group_name.split('_')
    return (' ').join(group_name_list[1:])

    RoomManager = "room-manager"
    VoucherManager = "voucher-manager"
    DashboardAdmin = "dashboard-admin"
    VoucherActivator = "voucher-activator"
    VoucherConsumer = "voucher-consumer"
    SystemAdmin = "system-admin" 

def format_role (role: str):
    # Map CD roles to our roles
    if role == "room_manager":
        return Role.query.filter(Role.name == constants.RoomManager).first()
    elif role == "voucher_manager":
        return Role.query.filter(Role.name == constants.VoucherManager).first()
    elif role == "dashboard_admin":
        return Role.query.filter(Role.name == constants.DashboardAdmin).first()
    elif role == "voucher_activate":
        return Role.query.filter(Role.name == constants.VoucherActivator).first()
    elif role == "voucher_consume":
        return Role.query.filter(Role.name == constants.VoucherConsumer).first()
    elif role == "system_admin":
        return Role.query.filter(Role.name == constants.SystemAdmin).first()
    else: return ""

def format_cd_roles(roles: list):
    return list(filter(None, map(format_role, roles)))

def create_otp_secret():
    secret = base64.b32encode(os.urandom(10)).decode('utf-8')
    return secret

def get_totp_uri(email, otp_secret, otp_issuer,):
    return f'otpauth://totp/{otp_issuer}:{email}?secret={otp_secret}&issuer={otp_issuer}'


def verify_totp(token, otp_secret):
    return onetimepass.valid_totp(token, otp_secret)


def unlockUser(user_id):
    user = User.query.filter_by(user_id=user_id).first()
    if user == None:
        raise ValueError(f"No user found with id {user_id}")

    user.locked = False
    user.password_attempts = 0
    user.otp_attempts = 0

    db.session.commit()

def lockUser( user ):
    user.locked = True
    user.password_attempts = 0
    user.otp_attempts = 0
    db.session.commit()
    
    # generate_account_locked_email(user)


def generate_account_locked_email(user):
    sending_from = userUtils.sendingFromEmail( user )

    params = {
        "email": user.login_id, 
        "baemail": sending_from,
    }

    # awsfunctions.sendEmail( 'account_locked', 'Referencing Portal Password Account Locked', params, [user.login_id], sending_from )

def generate_otp_email(user, otp_code):
    sending_from = userUtils.sendingFromEmail( user )

    params = {
        "otp_code": otp_code, 
        "email": user.login_id,
    }
    # awsfunctions.sendEmail( 'user_otp', 'Referencing Portal Password Login', params, [user.login_id], sending_from )


def generate_password_reset_email(user):
    # generate token
    token = base64.b32encode(os.urandom(20)).decode('utf-8')
    user.reset_password_token = token
    user.reset_password_expiry = arrow.now().shift(hours=1).datetime
    db.session.commit()

    # send email to user
    sending_from = userUtils.sendingFromEmail( user )

    params = {
        "token": token,
    }
    # awsfunctions.sendEmail( 'reset_password', 'Referencing Portal Password Reset', params, [user.login_id], sending_from )

def resetMFA(user):
    user.otp_secret = None
    db.session.commit()