import re
import arrow
from flask import session, request
from flask_login import login_user
from app import db
from app import utils
from app import userUtils
from app import awsfunctions
from app.IPWhitelistCache import ipWhitelistCache
from app.models import User

from . import authUtils

def log_user_in(user, cd_roles=[]):

    if cd_roles: 
        user.roles = authUtils.format_cd_roles(cd_roles)
        if not user.roles:
            awsfunctions.addAuditEntry( user, 'has-no-access', {} )
            return False
    
    # generate session id
    session_id = utils.generate_session_id()

    session["session_id"] = session_id

    # Only update the session if not a mobile user
    if 'is_mobile' not in session:
        user.session_id = session_id

    user.reset_password_token = None
    user.reset_password_expiry = None
    user.password_attempts = 0
    user.otp_attempts = 0
    user.last_logged_in = arrow.utcnow().datetime

    db.session.commit()

    login_user(user)

    details = {  }
    awsfunctions.addAuditEntry( user, 'logged_in', details )
    return True


def create_and_log_user_in(user_name, login_id, cd_roles):
    roles = []
    groups = []
    if not cd_roles: 
        return False
    
    roles = authUtils.format_cd_roles(cd_roles)

    if not roles:
        awsfunctions.addAuditEntry( None, 'has-no-access', {"login_id" : login_id} )

        return False
    
    user = User(login_id=login_id, name=user_name, roles=roles)
    db.session.add(user)
    db.session.commit()

    user = User.query.filter_by(login_id=login_id).first()
    log_user_in(user)
    return True

def handle_invalid_login_attempt(user):
    # store attempts in session
    user.password_attempts = user.password_attempts + 1
    
    if user.password_attempts > 3:
        authUtils.lockUser(user)

        awsfunctions.addAuditEntry( user, 'account_locked', {} )

    db.session.commit()
    return user.locked

def is_users_ip_whitelisted():
    return ipWhitelistCache.is_users_ip_whitelisted()
    
def password_check(password):
    """
    Verify the strength of 'password'
    Returns a dict indicating the wrong criteria
    A password is considered strong if:
        8 characters length or more
        1 digit or more
        1 symbol or more
        1 uppercase letter or more
        1 lowercase letter or more
    """

    # calculating the length
    length_error = len(password) < 8

    # searching for digits
    digit_error = re.search(r"\d", password) is None

    # searching for uppercase
    uppercase_error = re.search(r"[A-Z]", password) is None

    # searching for lowercase
    lowercase_error = re.search(r"[a-z]", password) is None

    # searching for symbols
    symbol_error = re.search(r"[ !#@$%&'()*+,-./[\\\]^_`{|}~"+r'"]', password) is None

    # overall result
    password_ok = not ( length_error or digit_error or uppercase_error or lowercase_error or symbol_error )

    ret = {'password_ok' : password_ok,}
    errors = ""
    if not password_ok:
        errors = "\n"
        if length_error:
            errors += "New password must be at least 8 chars or longer<br>"
        if digit_error:
            errors += "New password must have at least 1 numeric character<br>"
        if uppercase_error:
            errors += "New password must have at least 1 uppercase character<br>"
        if lowercase_error:
            errors += "New password must have at least 1 lowercase character<br>"
        if symbol_error:
            errors += "New password must have at least 1 symbolic character<br>"

    ret["errors"] = errors.strip()
    return ret
