import arrow
from datetime import datetime
from io import BytesIO
import logging
import logging.config
import json
import pyqrcode
from html import escape

from datetime import timedelta
from flask import Flask, render_template, url_for, flash, session, redirect, request, Response, abort
from flask import current_app as app
from requests import HTTPError
from flask_login import current_user, logout_user, login_required

from app.auth import auth_bp

from app import csrf, authClient
from app import awsfunctions
from app import constants
from app.models import User
from app import db
import json
from app import userUtils
from app.utils import logger, getClientIP
from app import csrf #, authClient
from requests import HTTPError

from . import routesServices
from . import authUtils
from .forms import (LoginForm, TwoFactorForm, ChangePasswordForm,
                    RequestResetPasswordForm, ResetPasswordForm, SetupMFAForm)


@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    """User login route."""
    if current_user.is_authenticated:
        # if user is logged in we get out of here
        return current_user.redirectToHome()

    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(login_id=form.login_id.data).first()

        # if we didn't find a user, just redirect to the login page
        if user is None or user.password_hash is None:
            flash('Your username and/or password were incorrect.')
            return redirect(url_for('.login'))

        # ensure account not locked
        sending_from = userUtils.sendingFromEmail( user )
        if user.locked:
            flash( f"Your account has been locked. Please contact {sending_from}.")
            return redirect(url_for('.login'))

        if not user.verify_password(form.password.data):
            if routesServices.handle_invalid_login_attempt(user) == True:
                flash(f"Your account has been locked. Please contact {sending_from}.")
            else:
                flash('Your username and/or password were incorrect.')
            return redirect(url_for('.login'))

        # check if user needs to change password - either explicity or due to password expiry
        if user.change_password or user.password_expires == None or user.password_expires <= arrow.now().date():
            if user.change_password:
                flash( "Please change your password." )
            else:
                flash( "Your password has expired. Please choose a new password." )
            session["login_id"] = user.login_id
            return redirect(url_for('.change_password'))

        # reset password attempts
        user.password_attempts = 0
        db.session.commit()

        # If staff user, user needs to do 2FA
        # check if users client ip is in the whitelist
        client_ip = getClientIP()
        logger.info(f"Client IP: {client_ip}")
        if routesServices.is_users_ip_whitelisted():

            # If user has specific roles, then force MFA 
            if user.has_any_roles([constants.RoomManager, constants.VoucherManager, constants.DashboardAdmin, constants.SystemAdmin]):
                session['login_id'] = user.login_id
                return redirect(url_for('.askTwoFactor'))
            else:
                routesServices.log_user_in(user)
                if "next" in session:
                    next = session['next']
                    session.pop('next', None)
                    return redirect(next)
                else:
                    return current_user.redirectToHome()
        else:
            # Send them to no access page
            flash( f"Access is not allowed from your IP address. Please try again after connecting to your company's network or VPN.")
            return redirect(url_for('.login'))
    else:
        if len(form.form_errors) > 0:
            flash(f'{form.errors}')

    return render_template('auth/login.html', form=form)



@auth_bp.route('/', endpoint='index')
@auth_bp.route('/index', endpoint='index')
@csrf.exempt
def index():
    return redirect(url_for('.login'))

@auth_bp.route("/staff_login")
@authClient.login_required
def staff_login():
    return redirect( "/" )


@auth_bp.route('/user/info', methods=['GET'], endpoint='user_info')
@authClient.token_required
@csrf.exempt
def user_info():
    try:
        return render_template('index.html', userInfo=authClient.get_user_details(), pretty=json.dumps(session.get('oauth_token'), indent=4))
    except HTTPError as e:
        log_error('Could not get user information because of: ', e)
        return render_template('auth/index.html')

@auth_bp.route('/home', methods=['GET'])
@authClient.token_required
def home():
    userInfo = authClient.get_user_details()
    if "Ops" in userInfo.get('role', []):
        return redirect(url_for("ops.home"))
    elif "CabinCrewOps" in userInfo.get('role', []):
        return redirect(url_for("ops.home"))
    elif "FlightCrewOps" in userInfo.get('role', []):
        return redirect(url_for("ops.home"))
    elif "FlightDispatch" in userInfo.get('role', []):
        return redirect(url_for("ops.home"))
    elif "FlightCrew" in userInfo.get('role', []):
        return redirect(url_for("crew.home"))
    elif "CabinCrew" in userInfo.get('role', []):
        return redirect(url_for("crew.home"))
    else:
        return redirect(url_for("auth.logout"))



@auth_bp.route('/handler', methods=['GET'], endpoint='handler')
@authClient.callback
@csrf.exempt
def callback():
    user_info = authClient.get_user_details()
    login_id=user_info.get('uid')
    staff_number = user_info.get('uid')
    user_name= constants.BA_USER
    user = User.query.filter_by(login_id=login_id).first()
    roles = user_info.get('role')

    if not roles:
        roles = [None]

    admin_route = 'admin.index'

    if user is None:
        user_created = routesServices.create_and_log_user_in(user_name, login_id, roles)
        if user_created:
                if "next" in session:
                    next = session['next']
                    session.pop('next', None)
                    return redirect(next)
                else:
                    return redirect(url_for(admin_route))
        else:
            flash("Please ensure you have the been assigned to the right groups and admin roles in Corporate Directory")
            return redirect(url_for('.logout'))
    else:
        if not routesServices.log_user_in(user, roles):
            flash("Please ensure you have the been assigned to the right groups and admin roles in Corporate Directory")
            return redirect(url_for('.logout'))
        
        if "next" in session:
            next = session['next']
            session.pop('next', None)
            return redirect(next)
        else:
            return redirect(url_for(admin_route))




@auth_bp.errorhandler(Exception)
def handle_error(error):
    if hasattr(error, 'code'):
        if error.code < 400:
            return Response.force_type(error, request.environ)
        elif error.code == 404:
            flash(str(error), 'danger')
            logging.error(str(error))
            return render_template('index.html'), 404
    flash(str(error), 'danger')
    logging.exception('Something went wrong. {}'.format(str(error)))
    return redirect( url_for('auth.logout') )


def log_error(message, error):
    error_details = error.response.json().get('details')
    error_msg = error_details[0].get('message') if error_details else error.response.json().get('message')
    flash(message + str(error_msg), 'danger')


# ---------- Custom Authentication

@auth_bp.route('/asktwofactor', methods=['GET', 'POST'])
def askTwoFactor():
    """Admin login route."""
    if current_user.is_authenticated:
        # if user is logged in we get out of here
        return current_user.redirectToHome()

    if 'login_id' not in session:
        return redirect(url_for('.login'))

    user = User.query.filter_by(login_id=session['login_id']).first()
    if user is None:
        session.pop('login_id', None)

        flash( "Your username and/or password were incorrect.")
        return redirect(url_for('.login'))

    # If the user hasn't setup their two factor yet - force them to do so
    if user.otp_secret == None:
        return redirect(url_for('.two_factor_setup'))

    form = TwoFactorForm()
    if form.validate_on_submit():
        if authUtils.verify_totp(form.token.data, user.otp_secret):
            # log user in

            # for added security, remove username from session
            session.pop('login_id', None)

            routesServices.log_user_in(user)

            if "next" in session:
                next = session['next']
                session.pop('next', None)
                return redirect(next)
            else:
                return current_user.redirectToHome()

        else:
            if user.otp_attempts == None:
                user.otp_attempts = 0
            user.otp_attempts = user.otp_attempts + 1
            if user.otp_attempts < 5:
                remaining = 5-user.otp_attempts
                flash( f"The code you provided was incorrect. Please try again ({remaining} attempt(s) remaining)." )
                db.session.commit()
            else:
                # Lock account
                authUtils.lockUser(user)

                session.clear()
                sending_from = userUtils.sendingFromEmail( user )
                flash(f"Your account has been locked because the code was entered incorrectly multiple times. Please contact {sending_from}.")
                return redirect(url_for('.login'))
    else:
        if len(form.form_errors) > 0:
            flash(f'{form.errors}')

    return render_template('auth/asktwofactor.html', form=form)

@auth_bp.route('/twoFactorSetup', methods=['GET', 'POST'])
def two_factor_setup():
    if 'login_id' not in session:
        return redirect(url_for('.login'))
    user = User.query.filter_by(login_id=session['login_id']).first()
    if user is None:
        return redirect(url_for('.login'))

    form = SetupMFAForm()
    if form.validate_on_submit():
        if 'otp_secret' not in session:
            return redirect(url_for('.login'))
        otp_secret = session["otp_secret"]
        if authUtils.verify_totp(form.token.data, otp_secret):
            session.pop('login_id', None)
            session.pop('otp_secret', None)

            user.otp_secret = otp_secret

            db.session.commit()

            routesServices.log_user_in(user)
            return redirect(url_for('admin.index'))
        else:
            if user.otp_attempts == None:
                user.otp_attempts = 0
            user.otp_attempts = user.otp_attempts + 1
            if user.otp_attempts < 5:
                remaining = 5-user.otp_attempts
                flash( f"The code you provided was incorrect. Please try again ({remaining} attempt(s) remaining)." )
                db.session.commit()

            else:
                # Lock account
                authUtils.lockUser(user)

                session.clear()
                sending_from = userUtils.sendingFromEmail( user )
                flash(f"Your account has been locked, please contact {sending_from}.")
                return redirect(url_for('.login'))
    else:
        if request.method == 'GET':

            # generate OTP Secret
            secret = authUtils.create_otp_secret()
            session["otp_secret"] = secret


    # since this page contains the sensitive qrcode, make sure the browser
    # does not cache it
    return render_template('auth/two-factor-setup.html', form=form), 200, {
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Expires': '0'}


@auth_bp.route('/qrcode')
def qrcode():
    if 'login_id' not in session or 'otp_secret' not in session:
        abort(404)
    user = User.query.filter_by(login_id=session['login_id']).first()
    if user is None:
        abort(404)

    login_id = session["login_id"]
    otp_secret = session["otp_secret"]

    # render qrcode for FreeTOTP
    url = pyqrcode.create(authUtils.get_totp_uri(login_id, otp_secret, app.config["OTP_ISSUER"]))
    stream = BytesIO()
    url.svg(stream, scale=3)
    return stream.getvalue(), 200, {
        'Content-Type': 'image/svg+xml',
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0'}


@auth_bp.route('/change_password', methods=['GET', 'POST'])
def change_password():

    # Ensure we have either a current user or a user login_id in the session
    if not current_user.is_authenticated and 'login_id' not in session:
        flash( "You are not logged in.")
        return redirect(url_for('.login'))

    if current_user.is_authenticated:
        user = current_user
    else:
        user = User.query.filter_by(login_id=session['login_id']).first()

        if user == None:
            flash( "You need to login first.")
            return redirect(url_for('.login'))

    form = ChangePasswordForm()
    if form.validate_on_submit():

        # Ensure that entered password matches current password
        if not user.verify_password(form.current_password.data):

            # store attempts in session
            user.password_attempts = user.password_attempts + 1

            if user.password_attempts > 3:
                authUtils.lockUser(user)

                sending_from = userUtils.sendingFromEmail( user )
                flash(f"Your account has been locked because your password was entered incorrectly multiple times. Please contact {sending_from}.")
                session.clear()

                return redirect(url_for('.login'))
            else:
                flash('Incorrect password.')
                db.session.commit()

            return redirect(url_for('.change_password'))

        password_check = routesServices.password_check( form.password.data )
        if password_check["password_ok"] != True:
            flash( "Invalid password: " + password_check["errors"] )
            return redirect(url_for('.change_password'))

        # remove login_id from session if it exists
        session.pop('login_id', None)

        # Reset users password
        password_expiry = arrow.utcnow().shift(days=+90).date()
        user.password_expires = password_expiry
        user.password = form.password.data
        user.password_attempts = 0
        user.change_password = 0
        db.session.commit()

        # If the user is already authenticated (i.e. they are changing their own password after logging in)
        # The redirect them to their home age
        # Otherwise, we need to get the user to relogin again (as they may also have to do 2FA)
        if current_user.is_authenticated:
            flash( 'Password changed successfully.')
            return user.redirectToHome()
        else:
            # If staff user, user needs to do 2FA
            if user.has_any_roles([constants.RoomManager, constants.VoucherManager, constants.DashboardAdmin, constants.SystemAdmin]):
                session['login_id'] = user.login_id
                return redirect(url_for('.askTwoFactor'))
            else:
                routesServices.log_user_in(user)
                if "next" in session:
                    next = session['next']
                    session.pop('next', None)
                    return redirect(next)
                else:
                    return current_user.redirectToHome()

    return render_template('auth/changePassword.html', form=form)

@auth_bp.route('/requestResetPassword', methods=['GET', 'POST'])
def requestResetPassword():

    form = RequestResetPasswordForm()
    if form.validate_on_submit():
        user = User.query.filter_by(login_id=form.login_id.data).first()
        if user is not None:

            authUtils.generate_password_reset_email(user)

        flash('If there is an account with your email address, you will receive an email with instructions to reset your password.')
        return redirect(url_for('.login'))

    return render_template('auth/requestResetPassword.html', form=form)

@auth_bp.route('/resetPassword/<string:token>', methods=['GET', 'POST'])
def resetPassword(token):
    error= False

    token = escape(token)
    if len(token) > 30:
        flash( 'The password reset link has expired or invalid. Please click "I forgot my password" to try again.')
        error= True
        return redirect(url_for('.login'))

    # Ensure we have a user that matches the token
    user = User.query.filter_by(reset_password_token=token).first()

    # Get the email to send from (if user is None then it uses the default)
    sending_from = userUtils.sendingFromEmail( user )

    if user == None:
        flash( f'The password reset link was expired or invalid. Please click "I forgot my password" to try again.')
        error= True
        return redirect(url_for('.login'))
    else:
        # ensure account not locked
        if user.locked:
            flash( f"Your account has been locked, please contact {sending_from}.")
            error= True

        # ensure token has not expired
        if user.reset_password_expiry < datetime.utcnow():
            flash( 'The password reset link has expired or invalid. Please click "I forgot my password" to try again.')
            error= True

        # Any errors, invalidate the token and return to login page
        if error:
            user.reset_password_token = None
            user.reset_password_expiry = None
            db.session.commit()
            return redirect(url_for('.login'))

        form = ResetPasswordForm()
        if form.validate_on_submit():

            password_check = routesServices.password_check( form.password.data )
            if password_check["password_ok"] != True:
                flash( "Invalid password: " + password_check["errors"] )
                return redirect(url_for('.resetPassword', token=token))


            user.reset_password_token = None
            user.reset_password_expiry = None
            user.password_attempts = 0
            user.change_password = 0

            # Reset users password
            password_expiry = arrow.utcnow().shift(days=+90).date()
            user.password_expires = password_expiry
            user.password = form.password.data
            db.session.commit()

            flash( 'Password changed successfully.')

            # If staff user, user needs to do 2FA
            if user.isStaff():
                session['login_id'] = user.login_id
                return redirect(url_for('.askTwoFactor'))

            routesServices.log_user_in(user)

            if "next" in session:
                next = session['next']
                session.pop('next', None)
                return redirect(next)

            return user.redirectToHome()

    return render_template('auth/resetPassword.html', token=token, form=form)

@auth_bp.route('/logout')
# @login_required
def logout():
    event_name = 'logout'

    awsfunctions.addAuditEntry(current_user, event_name, {})
    current_user.session_id = None
    db.session.commit()

    logout_user()

    # keep the _flashes if present
    flashes = None
    if '_flashes' in session:
        flashes = session['_flashes']

    session.clear()

    if flashes:
        session['_flashes'] = flashes



    return redirect(url_for('.login'))

