from flask import current_app as app

from app.models import User

def sendingFromEmail(user):
    if user is None :
        return app.config["EMAIL_SENDING_FROM"]

    return "andy.qua@iairgroup.com"

def getUserByAPIKey(api_key):
    if api_key == None:
        return None

    user = User.query.filter_by(api_key=api_key).first()
    return user