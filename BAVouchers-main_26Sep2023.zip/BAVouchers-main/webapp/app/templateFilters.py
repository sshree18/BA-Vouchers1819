import base64
import arrow
from flask import current_app as app

from app.constants import VoucherStatus

@app.template_filter()
def formatted(value):
    if value is None:
        value = ""
    value = value.replace( "\n", "<br/>" )
    return value


@app.template_filter()
def voucherStatusIcon(value):
    if value == VoucherStatus.PRINTED.value:
        return "fa-print"
    elif value == VoucherStatus.ACTIVATED.value:
        return "fa-ticket-alt"
    elif value == VoucherStatus.USED.value:
        return "fa-check"

@app.template_filter()
def voucherStatusColor(value):
    if value == VoucherStatus.PRINTED.value:
        return "bg-info"
    elif value == VoucherStatus.ACTIVATED.value:
        return "bg-success"
    elif value == VoucherStatus.USED.value:
        return "bg-warning"

@app.template_filter('base64_image')
def base64_image(image_name):
    # Load image from file
    with open(image_name, 'rb') as f:
        image = f.read()
    b64image = base64.b64encode(image).decode("utf-8")
    print( f"Returning ${b64image}")
    return b64image

@app.template_filter()
def local_time(time):
    t = arrow.get(time)
    return t.to('Europe/London').format('YYYY-MM-DD HH:mm:ss')

@app.template_filter()
def format_date(value):
    if value == None or value == "":
        return "Unknown"
    elif value == "Not added":
        return value
    return arrow.get(value).format("DD-MM-YYYY")

@app.template_filter()
def format_humanized(value):
    if value in {None, "", "Not added", "Never"}:
        return "Unknown"
    elif value == "Unknown":
        return "Unknown"
    return arrow.get(value).humanize(arrow.now())
