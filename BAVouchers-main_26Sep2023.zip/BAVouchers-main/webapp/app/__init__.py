import base64
import os
import datetime

from flask import Flask, request, session, render_template
from flask_wtf.csrf import CSRFProtect
from flask_login import LoginManager
from flask_migrate import Migrate
from flask_caching import Cache

from app import utils
from .database import DatabaseManager
from app.get_aws_settings import get_settings
from app.auth.services.auth import AuthClient

from app.config import configure_app

db = None
login_manager = LoginManager()
cache = Cache()
csrf = CSRFProtect()
migrate = Migrate()
databaseMgr = DatabaseManager()
authClient = AuthClient()

def create_app():
    global db

    app = Flask(__name__, instance_relative_config=True)
    app.config.from_pyfile('application.cfg', silent=False)
    app._static_folder = os.path.abspath("static/")

    configure_app(app)

    authClient.init_app(app)
    os.environ['OAUTHLIB_INSECURE_TRANSPORT'] = 'true'

    # Setup logging
    try: 
        utils.setupLogging(app.config.get("DEBUG", False))
    except Exception as e:
        print( f"Error setting up logging - {e}")
        raise e
        exit(-1)

    # Display some initial config - NON-SENSITIVE ONLY!
    utils.logger.info( f"App Name - {app.config.get('APP_NAME', 'Unknown')}" )
    utils.logger.info( f"App URL - {app.config.get('APP_URL', 'Unknown')}" )
    utils.logger.info( f"Environment - {app.config.get('FLASK_ENV', 'Unknown')}" )
    utils.logger.info( f"Debug - {app.config.get('DEBUG', 'Unknown')}" )

    # Setup flask caching and CSRF Timeout
    config = {
        "DEBUG": True,          # some Flask specific configs
        "CACHE_TYPE": "FileSystemCache",  # Flask-Caching related configs
        "CACHE_DIR": "/tmp/refzCache",
        "CACHE_DEFAULT_TIMEOUT": 300,
        "WTF_CSRF_TIME_LIMIT": 10800,   # 3 hours CSRF token timeout
    }
    app.config.from_mapping(config)
    cache.init_app(app)

    # Setup Flask-WTF forms - CSRF protection
    csrf.init_app(app)

    # Setup database
    databaseMgr.setup( app )
    db = databaseMgr.db

    # Setup Flask-Login
    login_manager.login_view = 'auth.login'
    login_manager.init_app(app)

    # Setup flask-sclalchemy migration tools
    # migrate.init_app(app, db)
    migrate.init_app(app, db, render_as_batch=True)


    with app.app_context():

        @app.errorhandler(404)
        def page_not_found(error):
            return render_template('404.html', title = '404'), 404

        # Set session timeout to be 3 hours of inactivity
        @app.before_request
        def before_request():
            session.permanent = True
            app.permanent_session_lifetime = datetime.timedelta(hours=3)
            session.modified = True


        # Disable caching
        @app.after_request
        def add_header(r):
            r.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
            r.headers["Pragma"] = "no-cache"
            r.headers["Expires"] = "0"
            r.headers['Cache-Control'] = 'public, max-age=0'
            return r

        @app.context_processor
        def utility_processor():
            def base64_image(tempFolder, image_name):
                filename = f"{tempFolder}/{image_name}.png"

                # Load image from file
                with open(filename, 'rb') as f:
                    image = f.read()
                b64image = base64.b64encode(image).decode("utf-8")
                print( f"Returning ${b64image}")
                return b64image
            return dict(base64_image=base64_image)

        from app.models import User

        # Define user loader function
        @login_manager.user_loader
        def load_user(user_id):
            # since the user_id is just the primary key of our user table, use it in the query for the user
            return User.query.get(int(user_id))

        # Import our Jinja template filters
        from app import templateFilters

        # register the blueprints
        from app.auth.routes import auth_bp
        app.register_blueprint(auth_bp, url_prefix='/oauth')
 
        from app.admin import admin_bp
        app.register_blueprint(admin_bp, url_prefix='/')

        return app
