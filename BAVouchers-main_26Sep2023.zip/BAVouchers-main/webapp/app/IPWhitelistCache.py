import ipaddress

from app.models import IPWhitelistItem
from app import utils
from app import cache

class IPWhitelistCache:
    def is_users_ip_whitelisted(self):
        clientIP = utils.getClientIP()

        whitelist = self.get_whitelisted_ips()

        # If we have any whitelist setup then apply the rules
        for ip in whitelist:
            # If we have a wildcard, then allow all IPs
            if ip == "*":
                return True
            if ipaddress.ip_address(clientIP) in ipaddress.ip_network(ip):
                return True

        return False

    def reloadCache(self):
        ip_whitelist_cache = []
        ip_whitelist = IPWhitelistItem.query.all()
        for ip in ip_whitelist:
            ip_whitelist_cache.append(ip.cidr)

        # If no items in the whitelist, then allow all IPs        
        if len(ip_whitelist) == 0:
            ip_whitelist_cache.append("*")

        cache.set("ip_whitelist_cache", ip_whitelist_cache)


    def get_whitelisted_ips(self):
        ip_whitelist_cache = cache.get("ip_whitelist_cache")

        if ip_whitelist_cache == None:
            self.reloadCache()
            ip_whitelist_cache = cache.get("ip_whitelist_cache")

        return ip_whitelist_cache

# Setup IPWhitelist cache
ipWhitelistCache = IPWhitelistCache()
