
from flask_sqlalchemy import SQLAlchemy
from random import randrange
import arrow
import random

from app import constants, utils

class DatabaseManager:
    db = SQLAlchemy()

    def setup( self, app ):

        self.db.init_app(app)
        if 'sqlite' in app.config['SQLALCHEMY_DATABASE_URI']:
            def _fk_pragma_on_connect(dbapi_con, con_record):  # noqa
                dbapi_con.execute('pragma foreign_keys=ON')

            with app.app_context():
                from sqlalchemy import event
                event.listen(self.db.engine, 'connect', _fk_pragma_on_connect)

    def createDBIfNeeded( self ):
        # Create a user to test with
        # self.db.create_all() 
        pass  

    def setupTestData(self):
        from .constants import RolesEnum
        
        from .models import (
            User,
            Role,
            Voucher,
        )

        if Role.query.filter_by(name="admin").first() is None:
            
            # create roles
            roomManagerRole = Role(name=RolesEnum.RoomManager.value)
            voucherManagerRole = Role(name=RolesEnum.VoucherManager.value)
            dashboardAdminRole = Role(name=RolesEnum.DashboardAdmin.value)
            voucherActivatorRole = Role(name=RolesEnum.VoucherActivator.value)
            voucherConsumerRole = Role(name=RolesEnum.VoucherConsumer.value)

            self.db.session.add( roomManagerRole )
            self.db.session.add( voucherManagerRole )
            self.db.session.add( dashboardAdminRole )
            self.db.session.add( voucherActivatorRole )
            self.db.session.add( voucherConsumerRole )

            self.db.session.commit()


            # create test admin user 
            password_expiry = arrow.utcnow().shift(days=+90).date()
            adminUser1 = User(login_id="admin@example.com", password="password", name="Admin", change_password=True, roles=[roomManagerRole, voucherManagerRole, dashboardAdminRole, voucherActivatorRole, voucherConsumerRole], password_expires=password_expiry)
            # adminUser1 = User(login_id="admin@example.com", password="password", name="Admin", otp_secret="2AUNAXS3UCHBDXDL", change_password=True, roles=[roomManagerRole, voucherManagerRole, dashboardAdminRole, voucherActivatorRole, voucherConsumerRole], password_expires=password_expiry)

            self.db.session.add(adminUser1)
            self.db.session.commit()

            # Create test Hotel
            from .models import Hotel
            hotel1 = Hotel(name="Marriot", default_room_allocation=50, rooms_available=50)
            hotel2 = Hotel(name="Hilton", default_room_allocation=50, rooms_available=50)

            self.db.session.add(hotel1)
            self.db.session.add(hotel2)
            self.db.session.commit()
