import os
import logging 
from app import utils
from app import awsfunctions

class BaseConfig(object):
    VERSION = "1.00"
    DEBUG = False
    TESTING = False
    PORT = 8080
    SCHEME = "https"


class LocalDevelopmentConfig(BaseConfig):
    DEBUG = True
    TESTING = True
    SCHEME = "http"

    SECRET_KEY = '46321A63-706B-4E90-9E89-39BC3073A933'
    ENDPOINT = "http://localhost:8080"
    OTP_ISSUER = "VouchersDev"

    EVENT_BUS = "NA"

    # OAuth2 / OIDC
    # Replace None with the URL of your local OAuth 2 server 
    AUTODISCOVER_URI = None #'http://localhost:4000/openid/.well-known/openid-configuration'
    CLIENT_ID = '362144'
    CLIENT_SECRET = 'e6f182f2187f082bda21475a0fd6ffc6cc00223c41aa83d2daaf07ed'
    TOKEN_AUTH_METHOD = 'client_secret_post'
    OAUTH_REDIRECT_PATH = '/callback'
    LOGOUT_URI = 'http://localhost:8080'
    SCOPE = 'profile email groups openid'
    MAX_AGE = 3600
    PROMPT = 'login'

class DevelopmentConfig(BaseConfig):
    DEBUG = True
    TESTING = True
    SCHEME = "http"
    SECRET_KEY = '5F48414B-CF54-4878-BF8D-8B2F8B312950'
    ENDPOINT = "http://localhost:8080"
    LOGOUT_URI = 'http://localhost:8080'

    SSM_APP_ROOT = "/BAVouchers/UAT"

class UATConfig(BaseConfig):
    DEBUG = True
    TESTING = True
    SCHEME = "https"

    SSM_APP_ROOT = "/BAVouchers/UAT"
    SESSION_COOKIE_SECURE = True

class ProductionConfig(BaseConfig):
    SSM_APP_ROOT = "/BAVouchers/PRD"
    SESSION_COOKIE_SECURE = True

config = {
    "localdev": "app.config.LocalDevelopmentConfig",
    "dev": "app.config.DevelopmentConfig",
    "uat": "app.config.UATConfig",
    "prd": "app.config.ProductionConfig",
    "default": "app.config.DevelopmentConfig"
}


def configure_app(app):
    config_name = "dev" if not "CONFIG" in os.environ else os.environ["CONFIG"]

    print( "Using config - {}".format(config_name))
    app.config.from_object(config[config_name])
    app.config.from_pyfile('config.cfg', silent=True)

    if config_name != "localdev":
        # Get settings from SSM and if they aren't already present (or the existing value is None)
        # then add them to the config
        settings = awsfunctions.get_settings(app.config['SSM_APP_ROOT'])
        for (key,val) in settings.items():
            if key not in app.config or app.config[key] == None:
                app.config[key] = val

    app.logger.setLevel(logging.INFO)

