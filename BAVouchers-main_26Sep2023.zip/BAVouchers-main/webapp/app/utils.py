import arrow
import os
from flask import request
from flask import current_app as app
from functools import wraps
from flask import make_response
import random
import secrets
import string
import uuid
import logging
import logging.config
import sys
from app import constants
from wtforms.validators import Regexp


logger = logging.getLogger('vouchers')

def setupLogging(debug):
    global logger

    logger.setLevel(logging.DEBUG)

    flaskLogger = logging.getLogger('flask_wtf.csrf')
    flaskLogger.setLevel(logging.INFO)

    if debug:
        handler = logging.StreamHandler(sys.stdout)
        handler.setLevel(logging.DEBUG)
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        handler.setFormatter(formatter)
        logger.addHandler(handler)

    # Set up file writer
    if debug:
        handler = logging.handlers.WatchedFileHandler('logs/app.log')
    else:
        handler = logging.handlers.WatchedFileHandler('/var/log/bavouchers/app.log')
    handler.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    flaskLogger.addHandler(handler)

    return logger

def generate_voucher_id():
    # Generate 2 sets of 3 random alpha characters each seperated by a dash
    # e.g. abc-def-ghi
    return f"{generate_random_string(3)}-{generate_random_string(3)}"

def generate_random_string(length):
    return ''.join(random.choices(string.ascii_lowercase, k=length))
    

def isLocal():
    return "SYSTEM" in os.environ and os.environ["SYSTEM"] != "PRODUCTION"

def generatePassword( length = 8 ):
    special_chars = "!@%()=?+.-"

    # Create a string that consists of 1  uppercase, 1 lowercase, 1 number, 1 special char - each randomly chosen
    # Then the remaining characters can be randomly chosen
    # Then as we have a predictable pattern - we shuffle it
    password = ""

    password += secrets.choice(string.ascii_uppercase)
    password += secrets.choice(string.ascii_lowercase)
    password += secrets.choice(string.digits)
    password += secrets.choice(special_chars)

    i = length - 4

    for i in range(0,4):
        password += secrets.choice(string.ascii_uppercase + string.ascii_lowercase + string.digits + special_chars)

    password = ''.join(random.sample(password,len(password)))

    return password

def generate_session_id():
    return secrets.token_urlsafe(32)

def getClientIP():

    if 'X-Forwarded-For' in request.headers:
        # print("X-Forwarded-For in Header found")
        proxy_data = request.headers['X-Forwarded-For']
        ip_list = proxy_data.split(',')
        ip = ip_list[0]  # first address in list is User IP
    else:
        # print("remote_addr")
        ip = request.remote_addr  # For local development

    # print(f"IP: {ip}")
    return ip


def extract_name_parts(name: str) -> dict:
    name_parts = name.split(" ")
    first_name = name_parts[0]
    middle_names = " ".join(name_parts[1:-1]) if len(name_parts) >= 3 else None
    last_name = name_parts[-1] if len(name_parts) >= 2 else None
    return dict(
        first_name=first_name,
        middle_names=middle_names,
        last_name=last_name
    )


def set_headers(view_func):
    @wraps(view_func)
    def wrapper(*args, **kwargs):
        headers = {
            "Cache-control": "no-store",
            "Pragma": "no-cache"
        }

        response = make_response(view_func(*args, **kwargs))
        response.headers.update(headers)
        return response

    return wrapper



def sanitize_filename(file_name):
    """
    Replace all type of punctuation with underscore
    """
    for symbol in [",", ";"]:
        file_name = file_name.replace(symbol, "_")
    return file_name

