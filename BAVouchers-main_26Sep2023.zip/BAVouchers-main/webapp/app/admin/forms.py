import re
import arrow
import datetime

from flask_wtf import FlaskForm
from wtforms import (
    StringField,
    IntegerField,
    TextAreaField,
    FileField,
    SubmitField,
    SelectField,
    DateField,
    SelectMultipleField,
    BooleanField,
    HiddenField,
    RadioField
)

from wtforms import widgets

from wtforms.validators import InputRequired, Length, NumberRange,  Optional, ValidationError, Regexp
from flask_wtf.file import FileField, FileRequired

class MultiCheckboxField(SelectMultipleField):
    widget = widgets.ListWidget(prefix_label=False)
    option_widget = widgets.CheckboxInput()

def basic_input_validator():
    return Regexp(
        # r':^[a-zA-Z0-9 ,.!?-]*$',
        r'[^#<>\[\]]*$',
        message="Input can not contain any of the following characters:: ^ # < > [ ]"
    )

def voucher_input_validator():
    return Regexp(
        r'^[a-zA-Z]{3}-[a-zA-Z]{3}$',
        # r'[^#<>\[\]]*$',
        message="Voucher code must be in the format : abc-def"
    )

def time_validator():
    return Regexp(
        r'^(0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$',
        message="Input must be in the format HH:MM"
    )


def text_input_area_validator():
    return Regexp(
        # r'^[a-zA-Z0-9 ,.!?\-\'\"&;()]+$',
        r'[^#<>\[\]]*$',
        message="Input can not contain any of the following characters:: ^ # < > [ ]"
    )

class AddRoomsForm(FlaskForm):
    hotel_name = StringField("Hotel Name", validators=[InputRequired(), Length(min=1, max=100), basic_input_validator()], render_kw={'readonly': True})
    nr_rooms = IntegerField("Number of rooms to add or remove (use negative numbers to remove rooms)", validators=[InputRequired(), NumberRange(min=-100, max=100)],render_kw={"placeholder": 'Please enter the number of rooms to add (max 100) or remove'})
    submit = SubmitField("Add rooms")

class AddHotelForm(FlaskForm):
    name = StringField("Hotel Name", validators=[InputRequired(), Length(min=1, max=100), basic_input_validator()], render_kw={'placeholder': 'The name of the hotel'})
    address = TextAreaField('Hotel Address:', validators=[InputRequired(), text_input_area_validator(), Length(min=1, max=300),  text_input_area_validator()], render_kw={"rows": 5})
    display_order = IntegerField("Display order", render_kw={"placeholder": 'Dispay order for the hotel in the list'})
    default_room_allocation = IntegerField("Number of rooms automatically allocated each day", render_kw={"placeholder": 'Please enter the number of rooms to auto allocate daily'})
    
    checkin_time = StringField("Check-in time (HH:MM 24hr format)", validators=[InputRequired(), Length(min=1, max=100), time_validator()], render_kw={'placeholder': 'e.g.: 14:00'})
    checkout_time = StringField("Check-out time (HH:MM 24hr format)", validators=[InputRequired(), Length(min=1, max=100), time_validator()], render_kw={'placeholder': 'e.g.: 12:00'})
    breakfast_times = StringField("Breakfast times", validators=[InputRequired(), Length(min=1, max=100), basic_input_validator()], render_kw={'placeholder': 'e.g.: 06:30 - 10:30'})
    dinner_times = StringField("Dinner times", validators=[InputRequired(), Length(min=1, max=100), basic_input_validator()], render_kw={'placeholder': 'e.g.: 18:30 - 23:00'})
    additional_info = StringField("Additional info", validators=[Optional(), Length(min=1, max=80), basic_input_validator()], render_kw={'placeholder': 'Additional information'})

    bau_safetystock_rate = IntegerField("BAU Safety Stock Percentage", render_kw={"placeholder": 'The percentage of expired activated vouchers to return to the BAU Safety Stock '})
    dis_safetystock_rate = IntegerField("DisDISruption Safety Stock Percentage", render_kw={"placeholder": 'The percentage of expired activated vouchers to return to the DIS Safety Stock '})

    bau_printed_expiry = IntegerField("BAU Printed voucher expiry", render_kw={"placeholder": 'The number of hours after which a BAU printed voucher expires'})
    dis_printed_expiry = IntegerField("DIS Printed voucher expiry", render_kw={"placeholder": 'The number of hours after which a DIS printed voucher expires'})

    bau_activated_expiry = IntegerField("BAU Activated voucher expiry", render_kw={"placeholder": 'The number of hours after which a BAU activated voucher expires'})
    dis_activated_expiry = IntegerField("DIS Activated voucher expiry", render_kw={"placeholder": 'The number of hours after which a DIS activated voucher expires'})

    submit = SubmitField("Create hotel")


class UpdateHotelForm(FlaskForm):
    name = StringField("Hotel Name", validators=[InputRequired(), Length(min=1, max=100), basic_input_validator()])
    address = TextAreaField('Hotel Address:', validators=[InputRequired(), text_input_area_validator(), Length(min=1, max=300),  text_input_area_validator()], render_kw={"rows": 5})
    display_order = IntegerField("Display order", render_kw={"placeholder": 'Dispay order for the hotel in the list'})
    default_room_allocation = IntegerField("Number of rooms automatically allocated each day", render_kw={"placeholder": 'Please enter the number of rooms to auto allocate daily'})

    checkin_time = StringField("Check-in time (HH:MM 24hr format)", validators=[InputRequired(), Length(min=1, max=5), time_validator()], render_kw={'placeholder': 'e.g.: 14:00'})
    checkout_time = StringField("Check-out time (HH:MM 24hr format)", validators=[InputRequired(), Length(min=1, max=5), time_validator()], render_kw={'placeholder': 'e.g.: 12:00'})
    breakfast_times = StringField("Breakfast times", validators=[InputRequired(), Length(min=1, max=100), basic_input_validator()], render_kw={'placeholder': 'e.g.: 06:30 - 10:30'})
    dinner_times = StringField("Dinner times", validators=[InputRequired(), Length(min=1, max=100), basic_input_validator()], render_kw={'placeholder': 'e.g.: 18:30 - 23:00'})
    additional_info = StringField("Additional info", validators=[Optional(), Length(min=1, max=80), basic_input_validator()], render_kw={'placeholder': 'Additional information'})

    bau_safetystock_rate = IntegerField("BAU Safety Stock Percentage", render_kw={"placeholder": 'The percentage of expired activated vouchers to return to the BAU Safety Stock'})
    dis_safetystock_rate = IntegerField("DIS Safety Stock Percentage", render_kw={"placeholder": 'The percentage of expired activated vouchers to return to the DIS Safety Stock'})

    bau_printed_expiry = IntegerField("BAU Printed voucher expiry (in hours)", render_kw={"placeholder": 'The number of hours after which a BAU printed voucher expires'})
    dis_printed_expiry = IntegerField("DIS Printed voucher expiry (in hours)", render_kw={"placeholder": 'The number of hours after which a DIS printed voucher expires'})

    bau_activated_expiry = IntegerField("BAU Activated voucher expiry (in hours)", render_kw={"placeholder": 'The number of hours after which a BAU activated voucher expires'})
    dis_activated_expiry = IntegerField("DIS Activated voucher expiry (in hours)", render_kw={"placeholder": 'The number of hours after which a DIS activated voucher expires'})

    submit = SubmitField("Update hotel details")

class SearchVoucherForm(FlaskForm):
    voucher_code = StringField("Enter voucher code", validators=[InputRequired(), Length(min=7, max=7), voucher_input_validator()], render_kw={"placeholder": 'Enter the voucher code - e.g. aaa-bbb'})
    submit = SubmitField("Lookup voucher details")


class MessageForm(FlaskForm):
    message_text = TextAreaField('Your message', validators=[ Length(0, 300)], render_kw={"placeholder": "Message to send"})

    submit = SubmitField('Send Message')


class IPWhitelistForm(FlaskForm):
    cidr = StringField('CIDR Range', validators=[InputRequired(), Length(1, 25), basic_input_validator()] )
    description = StringField('Description', validators=[InputRequired(), Length(1, 100)] )
    submit = SubmitField('Save')


class AddUserForm(FlaskForm):
    name = StringField("Users full name", validators=[InputRequired(), Length(min=1, max=100), basic_input_validator()], render_kw={"placeholder": "Users full name"})
    login_id = StringField('Login ID', validators=[InputRequired(), Length(1, 100)], render_kw={"placeholder": "Users login ID"})
    roles = MultiCheckboxField('Role', render_kw={'style': 'height: fit-content; padding-left:20; list-style: none;'})
    submit = SubmitField('Submit')

    def __init__(self, roles, *args, **kwargs):
        super(AddUserForm, self).__init__(*args, **kwargs)

        self.roles.choices = [x.name for x in roles]

    def validate_roles(form, field):
        if len(field.data) == 0:
            raise ValidationError("At least one role must be selected")

class UpdateUserDetailsForm(FlaskForm):
    user_id = HiddenField()
    roles = MultiCheckboxField('Role', render_kw={'style': 'height: fit-content; padding-left:20; list-style: none;'})

    resetPassword = BooleanField('Reset password')
    resetMFA = BooleanField('Reset MFA')
    submit = SubmitField('Submit')

    def __init__(self, roles, *args, **kwargs):
        super(UpdateUserDetailsForm, self).__init__(*args, **kwargs)

        self.roles.choices = [x.name for x in roles]

    def validate_roles(form, field):
        if len(field.data) == 0:
            raise ValidationError("At least one role must be selected")


class VoucherArchiveReportForm(FlaskForm):
    startDate = DateField('For', format='%d-%m-%Y', validators=[InputRequired()])
    submit = SubmitField('Submit')
