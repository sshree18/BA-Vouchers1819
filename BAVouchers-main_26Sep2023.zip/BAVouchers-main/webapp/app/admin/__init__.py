from flask import Blueprint

admin_bp = Blueprint('admin', __name__, template_folder='templates', static_folder="static", static_url_path='/admin/static')

from .routes import routes
from .routes import ajaxRoutes
from .routes import hotelManagementRoutes
from .routes import userManagementRoutes
from .routes import messageRoutes
from .routes import reportRoutes
