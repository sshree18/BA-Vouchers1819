import base64
from datetime import datetime, timedelta
import io
from flask import flash, render_template, session
from flask_login import current_user
import uuid
import os
import pyqrcode

from app import constants
from app.constants import VoucherStatus, IssueType
from app.models import User, Hotel, Batch, Voucher
from app import awsfunctions
from app import db
from app import utils

def getVoucher(voucher_id):
    voucher = Voucher.query.filter_by(voucher_id=voucher_id).first()
    if not voucher:
        raise ValueError(f"Voucher {voucher_id} not found")
    
    return voucher

def getHotel( hotel_name):
    hotel = Hotel.query.filter_by(name=hotel_name).first()
    if not hotel:
        raise ValueError(f"Hotel {hotel_name} not found")
    return hotel

def getHotelById( hotel_id ):
    hotel = Hotel.query.filter_by(id=hotel_id).first()
    if not hotel:
        raise ValueError(f"Hotel {hotel_id} not found")
    return hotel

def getBatch( batch_id):
    batch = Batch.query.filter_by(id=batch_id).first()
    if not batch:
        raise ValueError(f"Batch {batch_id} not found")
    
    return batch


    
def getBatchAsJSON( batch ):
    dict = batch.as_dict()
    dict['vouchers'] = []
    for voucher in batch.vouchers:
        dict['vouchers'].append(voucher.as_dict()) 
        if voucher.has_expired():
            dict['vouchers'][-1]['status'] = f"{voucher.status} / Expired"

    return dict

def activate_batch(batch_id, vouchers):
    batch = getBatch(batch_id)

    activated_vouchers = []
    for voucher in batch.vouchers:
        if len(vouchers) == 0 or voucher.voucher_id in vouchers:
            if voucher.status == VoucherStatus.PRINTED.value and not voucher.has_expired():
                activated_vouchers.append(voucher.voucher_id)
                voucher.activate()
    db.session.commit()

    details = { "batch_id" : batch_id, "activated_vouchers" : activated_vouchers}
    awsfunctions.addAuditEntry(current_user, 'activated_batch', details)

    return batch

def expire_batch(batch_id, type, vouchers):
    batch = getBatch(batch_id)

    expired_vouchers = []
    for voucher in batch.vouchers:
        if len(vouchers) == 0 or voucher.voucher_id in vouchers:
            voucher.expire(type)
            expired_vouchers.append(voucher.voucher_id)
    db.session.commit()

    details = { "batch_id" : batch_id, "expired_vouchers" : expired_vouchers}
    awsfunctions.addAuditEntry(current_user, 'expired_batch', details)

    return batch

def reset_batch(batch_id, voucherList):
    batch = getBatch(batch_id)

    reset_vouchers = []
    for voucher in batch.vouchers:
        if len(voucherList) == 0 or voucher.voucher_id in voucherList:
            # Do not reset used vouchers
            if voucher.status != VoucherStatus.USED.value:
                voucher.issued(voucher.issue_type)
                voucher.printed_by = None
                voucher.printed_at = None
                voucher.activated_by = None
                voucher.activated_at = None
                voucher.used_by = None
                voucher.used_at = None
                reset_vouchers.append(voucher.voucher_id)

    db.session.commit()

    details = { "batch_id" : batch_id, "reset_vouchers" : reset_vouchers}
    awsfunctions.addAuditEntry(current_user, 'reset_batch', details)

    return batch

def updateVoucherStatus(voucher_id):
    voucher = getVoucher(voucher_id)

    status = ""
    if voucher == None:
        raise ValueError(f"Voucher {voucher_id} not found")

    if voucher.status == VoucherStatus.PRINTED.value:
        voucher.activate()
        status = "Voucher activated"
    elif voucher.status == VoucherStatus.ACTIVATED.value:
        if areRoomsAvailableForVoucher(voucher):
            voucher.use()
            status = "Voucher used"
        else:
            raise ValueError(f"No rooms available for voucher {voucher_id}")
    elif voucher.status == VoucherStatus.ISSUED.value:
        raise ValueError(f"Voucher {voucher_id} has not yet been printed")
    elif voucher.status == VoucherStatus.USED.value:
        raise ValueError(f"Voucher {voucher_id} has already been used")

    details = { "batch_id" : voucher.batch_id, "voucher_id" : voucher_id, "status" : status}
    awsfunctions.addAuditEntry(current_user, "update_voucher_status", details)

    db.session.commit()
    return status

def areRoomsAvailableForVoucher(voucher):
    # If the voucher hasn't yet expired, then we have a room available
    if not voucher.has_expired():
        return True
    
    # Voucher has expired, do we have any rooms available either in the safety stock , or our allocation for the hotel?
    details = calculate_hotel_summary( voucher.hotel )
    rooms_available = details['rooms_available'] + details['safety_stock']
    if rooms_available > 0:
        return True
    
    return False

def calculate_hotel_summary(hotel):

    details = {
        "hotel_id": hotel.id,
        "rooms_booked": hotel.rooms_available,
        "rooms_available": hotel.rooms_available,
        "rooms_pending_checkin": 0,
        "rooms_checkedin": 0,
        "safety_stock": 0,
        "overbooked": 0,
        VoucherStatus.ISSUED.value : { 'issued': 0 },
        VoucherStatus.PRINTED.value : { 'expired': 0, 'unexpired': 0 },
        VoucherStatus.ACTIVATED.value : { 'expired': 0, 'unexpired': 0 },
        VoucherStatus.USED.value : { 'ontime': 0, 'late': 0 },
    }

    rooms_available = hotel.rooms_available
    safety_stock_bau = 0
    safety_stock_dis = 0
    allocated_from_safety_stock = 0
    for voucher in hotel.vouchers:
        if voucher.status == VoucherStatus.ISSUED.value:
            if not voucher.has_expired():                
                details[voucher.status]['issued'] += 1
                rooms_available -= 1
        elif voucher.status == VoucherStatus.USED.value:
            details['rooms_checkedin'] += 1

            if voucher.has_expired():
                details[VoucherStatus.USED.value]['late'] += 1

                # Take off late allocated rooms from the safety store (as that is what they were allocated from)
                allocated_from_safety_stock += 1

                # Increase the relevant safety stock by one (it gets taken off later)
                if voucher.issue_type == IssueType.BAU.value:
                    safety_stock_bau += 1
                else:
                    safety_stock_dis += 1
            else:
                details[VoucherStatus.USED.value]['ontime'] += 1
                rooms_available -= 1


        elif voucher.has_expired():
            details[voucher.status]['expired'] += 1

            if voucher.status == VoucherStatus.ACTIVATED.value:
                if voucher.issue_type == IssueType.BAU.value:
                    safety_stock_bau += 1
                else:
                    safety_stock_dis += 1
        else:
            if voucher.status == VoucherStatus.ACTIVATED.value:                
                details['rooms_pending_checkin'] += 1
            details[voucher.status]['unexpired'] += 1
            rooms_available -= 1

    # Calculate safety stock
    # Safety stock - is 10% of expired activated vouchers during BAU or 20% of expired activated vouchers during DIS

    safety_stock_bau = int((safety_stock_bau * hotel.bau_safetystock_rate)/100)
    safety_stock_dis = int((safety_stock_dis * hotel.bau_safetystock_rate)/100)
    safety_stock = safety_stock_bau + safety_stock_dis

    # Remove the allocated safety stock from the rooms available
    rooms_available -= safety_stock

    # Remove any late allocated rooms from the safety stock
    safety_stock -= allocated_from_safety_stock

    # If the new safety stock is less than 0, then we need to take as many rooms from the rooms available as possible
    overbookedRooms = 0
    if safety_stock < 0:
        while rooms_available > 0 and safety_stock < 0:
            safety_stock += 1
            rooms_available -= 1

        overbookedRooms = -1 * safety_stock
        safety_stock = 0

    details['safety_stock'] = safety_stock
    details['overbooked'] = overbookedRooms
    details['rooms_available'] = rooms_available

    return details


def getVoucherSummary():

    hotels = Hotel.query.order_by(Hotel.display_order).all()
    vouchers = Voucher.query.all()

    summary = {}
    total = {
        "hotel_id": 'TOTAL',
        "rooms_booked": 0,
        "rooms_available": 0,
        "rooms_pending_checkin": 0,
        "rooms_checkedin": 0,
        "safety_stock": 0,
        "overbooked": 0,
        VoucherStatus.ISSUED.value : { 'issued': 0 },
        VoucherStatus.PRINTED.value : { 'expired': 0, 'unexpired': 0 },
        VoucherStatus.ACTIVATED.value : { 'expired': 0, 'unexpired': 0 },
        VoucherStatus.USED.value : { 'ontime': 0, 'late': 0 },
    }
    for hotel in hotels:

        val = calculate_hotel_summary( hotel )

        total["rooms_booked"] += val["rooms_booked"]
        total["rooms_available"] += val["rooms_available"]
        total["rooms_pending_checkin"] += val["rooms_pending_checkin"]
        total["rooms_checkedin"] += val["rooms_checkedin"]
        total["safety_stock"] += val["safety_stock"]
        total["overbooked"] += val["overbooked"]
        total[VoucherStatus.ISSUED.value]['issued'] += val[VoucherStatus.ISSUED.value]['issued']
        total[VoucherStatus.PRINTED.value]['expired'] += val[VoucherStatus.PRINTED.value]['expired']
        total[VoucherStatus.PRINTED.value]['unexpired'] += val[VoucherStatus.PRINTED.value]['unexpired']
        total[VoucherStatus.ACTIVATED.value]['expired'] += val[VoucherStatus.ACTIVATED.value]['expired']
        total[VoucherStatus.ACTIVATED.value]['unexpired'] += val[VoucherStatus.ACTIVATED.value]['unexpired']
        total[VoucherStatus.USED.value]['ontime'] += val[VoucherStatus.USED.value]['ontime']
        total[VoucherStatus.USED.value]['late'] += val[VoucherStatus.USED.value]['late']

        summary[hotel.name] = val

    return total, summary,

def issue_vouchers(hotel, nrVouchers, issue_type, description):

    # Create new Batch
    # Get midnight tomorrow
    batch = Batch( hotel_id=hotel.id, description=description, created_by=current_user.login_id, created_at=datetime.utcnow())

    # get list of voucher ids from Voucher table
    existing_vouchers = Voucher.query.with_entities(Voucher.voucher_id).all()

    vouchers = []
    for i in range(nrVouchers):

        # Generate voucher id
        valid = False
        while not valid:
            voucher_id = utils.generate_voucher_id()
            if not voucher_id in existing_vouchers:
                existing_vouchers.append(voucher_id)
                valid = True

        voucher = Voucher(voucher_id=str(voucher_id))
        voucher.issued(issue_type)
        batch.vouchers.append(voucher)
        hotel.vouchers.append(voucher)

        vouchers.append( voucher )
    
    try:
        db.session.add(batch)
        db.session.commit()
    except Exception as e:
        raise ValueError(f"Error creating batch: {e}")

    details = { "batch_id" : batch.id, "nr_vouchers" : nrVouchers, "issue_type" : issue_type, "hotel" : hotel.name}
    awsfunctions.addAuditEntry(current_user, "issued_vouchers", details)

    return batch.id

def print_batch(batch_id, vouchers):

    # Get batch
    batch = getBatch(batch_id)
    hotel = batch.hotel

    # load BA Logo and base64 it
    logo = os.path.join(os.getcwd(), 'static', 'images', 'balogo.png')
    if not os.path.exists(logo):
        raise ValueError(f"BA Logo not found: {logo}")
    with open(logo, "rb") as image_file:
        balogo_image = base64.b64encode(image_file.read()).decode("ascii")
    
    # Generate QRCodes
    try:  

        printed_vouchers = []
        printed_voucher_codes = []
        for voucher in batch.vouchers:
            if len(vouchers) == 0 or voucher.voucher_id in vouchers:
                if voucher.status == VoucherStatus.USED.value or voucher.status == VoucherStatus.ACTIVATED.value or voucher.has_expired():
                    continue
                if voucher.status == VoucherStatus.ISSUED.value:
                    voucher.printed()

                # get temp filename
                qr = pyqrcode.create(voucher.voucher_id)

                s = io.BytesIO()
                qr.png(s,scale=5)
                encoded = base64.b64encode(s.getvalue()).decode("ascii")

                voucher.qr_code = encoded
                printed_vouchers.append(voucher)
                printed_voucher_codes.append(voucher.voucher_id)

        batch.has_been_printed = True
        db.session.commit()

        details = { "batch_id" : batch.id, "hote    l" : hotel.name, "printed_vouchers" : printed_voucher_codes }
        awsfunctions.addAuditEntry(current_user, "printed_vouchers", details)

        voucher_expiry = hotel.bau_activated_expiry if batch.vouchers[0].issue_type == "BAU" else hotel.dis_activated_expiry

        useBy = int(hotel.checkin_time.split(":")[0]) + 4
        voucher_use_by = f"{useBy}:00"
        context = {
            'hotel' : hotel,
            'batch_id' : batch_id,
            'vouchers': printed_vouchers,
            'balogo_image': balogo_image,
            'voucher_expiry' : voucher_expiry,
            'voucher_use_by' : voucher_use_by,
            'voucher_date' : datetime.utcnow().strftime("%d %b %Y")
        }
        html = render_template("admin/voucher_template.html", **context)
        return html, hotel.name

    except Exception as e:
        raise ValueError(f"Error generating QR Code - {e}")
    

def add_rooms(hotel, nr_rooms):
    hotel.rooms_available += nr_rooms
    db.session.commit()

    details = { "hotel_name" : hotel.name, "nr_rooms" : nr_rooms}
    awsfunctions.addAuditEntry(current_user, "added_hotel_rooms", details)


def getApiKey():
    user = User.query.filter_by(login_id=current_user.login_id).first()
    if not user:
        raise ValueError(f"User {current_user.login_id} not found")

    # make sure api key was issued today, if not, issue a new one
    if user.api_key_issued_at != None and user.api_key_issued_at.date().day != datetime.utcnow().date().day:
        user.api_key = None
        user.api_key_issued_at = None

    if not user.api_key:
        user.api_key = uuid.uuid4().hex
        user.api_key_issued_at = datetime.utcnow()
        db.session.commit()

    details = {}
    awsfunctions.addAuditEntry(current_user, "mobile-user-api-key", details)

    return user.api_key


""" This is test and development code only """
def resetData():
# delete all batches
    Batch.query.delete()

    # Reset hotel rooms to 0
    hotels = Hotel.query.all()
    for hotel in hotels:
        hotel.rooms_available = hotel.default_room_allocation
    
    db.session.commit()

    details = {}
    awsfunctions.addAuditEntry(current_user, "reset-system-data", details)
