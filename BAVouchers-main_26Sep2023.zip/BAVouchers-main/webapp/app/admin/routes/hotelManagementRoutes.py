import arrow
from flask import render_template, redirect, url_for, flash, request, session
from flask import current_app as app
from flask_login import current_user

from app.constants import (
    RoomManager, DashboardAdmin
)
from . import hotelManagementServices
from app.roles import roles_required
from app.utils import logger, set_headers

from app.auth import authUtils

from app import constants

from app.admin.forms import ( AddHotelForm, UpdateHotelForm)

from app.admin import admin_bp


#------------------------------------------------------
# Add and Edit hotel details
#------------------------------------------------------



@admin_bp.route("/manageHotels", methods=['GET', 'POST'])
@set_headers
@roles_required([DashboardAdmin])
def manage_hotels():

    hotels = hotelManagementServices.getHotels( )

    context = {
        "hotels" : hotels,
    }
    return render_template("admin/manageHotels.html", user=current_user, **context)


@admin_bp.route("/addHotel", methods=['GET', 'POST'])
@set_headers
@roles_required([DashboardAdmin])
def addHotel():

    form = AddHotelForm(checkin_time="14:00", checkout_time="12:00", breakfast_times="06:30 - 10:30", dinner_times="18:30 - 22:30", default_room_allocation=50, bau_safetystock_rate=10, dis_safetystock_rate=10, bau_printed_expiry=1, dis_printed_expiry=1, bau_activated_expiry=4, dis_activated_expiry=4)
    if form.validate_on_submit():
        try:

            hotelManagementServices.addhotel(form)

            flash("Hotel created", "success")
            return redirect(url_for('.manage_hotels'))
        except Exception as e:
            flash(str(e))
            logger.error( "Error adding hotel: " + str(e) )

    return render_template("admin/addHotel.html", user=current_user, form=form)

@admin_bp.route("/editHotel/<int:hotel_id>", methods=['GET', 'POST'])
@set_headers
@roles_required([DashboardAdmin])
def editHotel(hotel_id):

    hotel = hotelManagementServices.getHotel(hotel_id)

    form = UpdateHotelForm(name=hotel.name, address=hotel.address,
                           display_order=hotel.display_order,
                           checkin_time=hotel.checkin_time, checkout_time=hotel.checkout_time,
                           breakfast_times=hotel.breakfast_times, dinner_times=hotel.dinner_times,
                           additional_info=hotel.additional_info,
                           default_room_allocation=hotel.default_room_allocation,
                           bau_safetystock_rate=hotel.bau_safetystock_rate, dis_safetystock_rate=hotel.dis_safetystock_rate,
                           bau_printed_expiry=hotel.bau_printed_expiry, dis_printed_expiry=hotel.dis_printed_expiry,
                           bau_activated_expiry=hotel.bau_activated_expiry, dis_activated_expiry=hotel.dis_activated_expiry)

    if form.validate_on_submit():
        try:
            
            hotelManagementServices.updatehotel(hotel_id, form)

            flash("Hotel updated", "success")
            return redirect(url_for('.manage_hotels'))
        except Exception as e:
            flash(str(e))
            logger.error( "Error updated hotel: " + str(e) )

    context = {
        "hotel" : hotel,
        "form" : form,
    }


    return render_template("admin/editHotel.html", user=current_user, **context)
        

@admin_bp.route("/deleteHotel/<int:hotel_id>", methods=['POST'])
@set_headers
@roles_required([DashboardAdmin])
def deleteHotel(hotel_id):
    try:
        hotelManagementServices.deleteHotel( hotel_id)
        flash( "Hotel deleted", "success" )

        return "OK"
    except Exception as e:
        flash( str(e) )
        logger.error( "Error deleting hotel: " + str(e) )
        return "Error"



