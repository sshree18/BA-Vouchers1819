from datetime import datetime
from html import escape

from flask import redirect, url_for, render_template, flash, request, Response, jsonify
from flask_login import current_user
from app.roles import roles_required

from flask import current_app as app

from app.admin import admin_bp

from app import constants
from app import authClient
from app import csrf
from app.utils import logger, set_headers

from app.admin.forms import AddRoomsForm, SearchVoucherForm
from app.constants import VoucherStatus, RolesEnum
from . import routesServices
from . import messageServices


@admin_bp.route('/oauth/2handler', methods=['GET'], endpoint='oauth/handler')
@authClient.callback
@csrf.exempt
def callback():
    return redirect(url_for('.index'))

@admin_bp.route("/")
@admin_bp.route("/index")
@set_headers
@roles_required([constants.RoomManager, constants.VoucherManager, constants.VoucherActivator, constants.VoucherConsumer, constants.DashboardAdmin])
def index():

    if current_user.has_role(constants.RoomManager) or current_user.has_role(constants.VoucherManager) or current_user.has_role(constants.DashboardAdmin):
        return redirect( url_for('.home') )
    elif current_user.has_role(constants.VoucherActivator) or current_user.has_role(constants.VoucherConsumer):
        return redirect( url_for('.scanVoucher') )
    else:
        return redirect( url_for('.accessDenied') )
    
@admin_bp.route("/home")
@set_headers
@roles_required([constants.RoomManager, constants.VoucherManager, constants.DashboardAdmin])
def home():

    total, summary = routesServices.getVoucherSummary()

    unread_messages = messageServices.getUnreadMessageCount(current_user)

    context = {
        "total": total,
        "summary": summary,
        "VoucherStatus" : VoucherStatus,
        "unread_messages": unread_messages,
        "RolesEnum": RolesEnum,
    }

    return render_template( 'admin/home.html', user=current_user, **context )
    

@admin_bp.route("/showDetails/<int:hotel_id>", methods=['GET'])
@admin_bp.route("/showDetails/<int:hotel_id>/<int:batch_id>", methods=['GET'])
@set_headers
@roles_required([constants.VoucherManager])
def showDetails(hotel_id, batch_id=None):

    try:
        hotel = routesServices.getHotelById(hotel_id)
    except:
        flash(f"Invalid hotel {hotel_id}", 'danger')
        return redirect( url_for('.index') )

    batch = None
    if batch_id is not None:
        try:
            batch_id = int(str(batch_id))
            batch = routesServices.getBatch(batch_id)
            batch = routesServices.getBatchAsJSON(batch)
        except:
            flash(f"Invalid batch id {batch_id}", 'danger')
            return redirect( url_for('.showDetails', hotel_id=hotel_id) )


    context = {
        "hotel": hotel,
        "batch": batch,
        "selected_batch_id": batch_id,
    }
    return render_template('admin/showDetails.html', user=current_user, **context)


@admin_bp.route("/addRooms/<int:hotel_id>", methods=['GET', 'POST'])
@set_headers
@roles_required([constants.RoomManager])
def addRooms(hotel_id):

    try:
        hotel = routesServices.getHotelById(hotel_id)
    except:
        flash(f"Invalid hotel {hotel_id}", 'danger')
        return redirect( url_for('.index') )
    
    details = routesServices.calculate_hotel_summary( hotel )
    rooms_available = details['rooms_available']

    rooms_allocated = hotel.rooms_available - rooms_available

    form = AddRoomsForm(hotel_name=hotel.name)
    if form.validate_on_submit():
        hotel_name = form.hotel_name.data
        nr_rooms = form.nr_rooms.data
        try:
            try:
                nr_rooms = int(str(nr_rooms))
            except:
                raise ValueError("Number of rooms must be a number")
            if nr_rooms > 100:
                raise ValueError("You can only request up to 100 additional rooms at a time")
            if nr_rooms < 0 and rooms_available + nr_rooms < 0:
                raise ValueError( "You can't remove more rooms than there are available")

            routesServices.add_rooms(hotel, nr_rooms)

            flash( f"Added {nr_rooms} rooms to {hotel.name}", 'success')
            return redirect(url_for('.addRooms', hotel_id=hotel.id))

        except ValueError as e:
            flash(str(e), 'danger')

    context = {
        "form": form,
        "total_rooms" : hotel.rooms_available,
        "rooms_allocated" : rooms_allocated,
        "rooms_available" : rooms_available,
        "hotel" : hotel,
    }
    return render_template( 'admin/addRooms.html', user=current_user, **context )

@admin_bp.route("/scanVoucher", methods=['GET'])
@set_headers
@roles_required([constants.VoucherActivator, constants.VoucherConsumer])
def scanVoucher():

    return render_template( 'admin/scanVoucher.html', user=current_user )

@admin_bp.route("/lookupVoucher", methods=['GET', 'POST'])
@set_headers
@roles_required([constants.VoucherActivator, constants.VoucherConsumer])
def lookupVoucher():
    voucher = None

    form = SearchVoucherForm()
    if form.validate_on_submit():
        try:
            voucher = routesServices.getVoucher(form.voucher_code.data)
        except ValueError as e:
            flash(str(e), 'danger')

    context = {
        'form': form,
        'voucher': voucher,
    }
    return render_template( 'admin/lookupVoucher.html', user=current_user, **context )


@admin_bp.route("/rolesOverview")
@set_headers
@roles_required([constants.RoomManager, constants.VoucherManager, constants.DashboardAdmin ])
def rolesOverview():
    return render_template( 'admin/rolesOverview.html', user=current_user )

@admin_bp.route("/dashboardDefs")
@set_headers
@roles_required([constants.RoomManager, constants.VoucherManager, constants.DashboardAdmin])
def dashboardDefs():
    return render_template( 'admin/dashboardDefs.html', user=current_user )

@admin_bp.route("/whatsNew")
@set_headers
@roles_required([constants.RoomManager, constants.VoucherManager, constants.DashboardAdmin])
def whatsNew():
    return render_template( 'admin/whatsNew.html', user=current_user )

@admin_bp.route("/cookie-policy")
def cookiePolicy():
    return render_template("admin/cookiepolicy.html")
