from flask import request, flash, Response
from flask_login import current_user
from html import escape
import re

from app.roles import roles_required, api_key_required_if_not_logged_in

from app.admin import admin_bp

from app import csrf
from app import constants
from app.utils import logger, set_headers

from . import routesServices
from . import messageServices

@admin_bp.route("/voucher_summary")
@set_headers
@roles_required([constants.RoomManager, constants.VoucherManager, constants.DashboardAdmin])
def get_voucher_summary():
    total, summary = routesServices.getVoucherSummary()
    unread_messages = messageServices.getUnreadMessageCount(current_user)

    return { "total":total, 
            "summary":summary,
            "unread_messages" : unread_messages }

@admin_bp.route("/get_available_rooms", methods=['POST'])
@set_headers
@roles_required([constants.RoomManager, constants.VoucherManager])
def get_available_rooms():

    try:
        hotel_id = int(request.form.get('hotel_id'))
        hotel = routesServices.getHotelById(hotel_id)
        details = routesServices.calculate_hotel_summary(hotel)
        rooms_available = details['rooms_available']

        return { "status": "ok", "rooms_available" : rooms_available }
    except ValueError as e:
        logger.error(f"Hotel not found - {e}")
        return {"status" : "error", "reason" : "Hotel not found" }
    

@admin_bp.route("/issue_vouchers", methods=['POST'])
@set_headers
@roles_required([constants.VoucherManager])
def issue_vouchers():

    try:
        hotel_id = int(request.form.get('hotel_id', "unknown"))

        try:
            nr_vouchers = int(request.form.get('number_of_vouchers'))
        except:
            return {"status" : "error", "reason" : f"Vouchers requested must be a number" }

        if nr_vouchers == 0 or nr_vouchers > 100:
            return {"status" : "error", "reason" : "The number of vouchers in a batch must be between 1 and 100" }

        issue_type = request.form.get('issue_type')
        if issue_type != "BAU" and issue_type != "DIS":
            return {"status" : "error", "reason" : f"Invalid issue type" }
        
        description = request.form.get('description')
        if description != None and re.match( r'[^#<>\[\]]*$', description ) == None:
            return {"status" : "error", "reason" : "Description can not contain any of the following characters:: ^ # < > [ ]" }

        try:
            hotel = routesServices.getHotelById(hotel_id)
        except ValueError as e:
            logger.error(f"Hotel {hotel_id} not found - {e}")
            return {"status" : "error", "reason" : "Hotel not found" }

        # Double validate no-one is being sneaky!
        details = routesServices.calculate_hotel_summary(hotel)
        rooms_available = details['rooms_available']
        if nr_vouchers > rooms_available:
            return {"status" : "error", "reason" : f"Too many vouchers requested!" }

        batch_id = routesServices.issue_vouchers(hotel, nr_vouchers, issue_type, description)

        flash( f"Batch {batch_id} created with {nr_vouchers} vouchers", 'success')
        return { "status" : "ok", "batch_id" : batch_id }
    except ValueError as e:
        logger.error(f"Error issuing vouchers - {e}")
        return {"status" : "error", "reason" : f"Error issuing vouchers - {e}" }


@admin_bp.route("/get_batch_details/<int:batch_id>", methods=['GET'])
@set_headers
@roles_required([constants.VoucherManager])
def getBatchDetails(batch_id):

    batch_id = batch_id

    try:
        batch = routesServices.getBatch(batch_id)
    except ValueError as e:
        logger.error(f"Batch {batch_id} not found - {e}")
        return {"status" : "error", "reason" : "Batch not found" }

    return { "status" : "success", "batch" : routesServices.getBatchAsJSON(batch) }

@admin_bp.route("/activate_batch", methods=['POST'])
@set_headers
@roles_required([constants.VoucherManager])
def activate_batch():

    try:
        resp = request.json
        batch_id = int(resp.get('batch_id', "INVALID"))
        vouchers = resp.get( "vouchers", [])
    except:
        return {"status" : "error", "reason" : "Invalid data supplied" }
    
    try:
        batch = routesServices.activate_batch(batch_id, vouchers)
        return { "status" : "success", "batch" : routesServices.getBatchAsJSON(batch) }
    except ValueError as e:
        logger.error(f"Batch {batch_id} not found - {e}")
        return {"status" : "error", "reason" : "Batch not found" }

@admin_bp.route("/expire_batch", methods=['POST'])
@set_headers
@roles_required([constants.VoucherManager])
def expire_batch():
    try:
        resp = request.json

        batch_id = int(resp.get('batch_id', "INVALID"))
        type = resp.get('type', "INVALID")
        vouchers = resp.get( "vouchers", [])

        if type != "issued" and type != "activated":
            raise ValueError("Invalid type supplied")
    except:
        return {"status" : "error", "reason" : "Invalid data supplied" }


    try:
        batch = routesServices.expire_batch(batch_id, type, vouchers)
        return { "status" : "success", "batch" : routesServices.getBatchAsJSON(batch) }
    except ValueError as e:
        logger.error(f"Batch {batch_id} not found - {e}")
        return {"status" : "error", "reason" : "Batch not found" }

@admin_bp.route("/reset_batch", methods=['POST'])
@set_headers
@roles_required([constants.VoucherManager])
def reset_batch():
    try:
        resp = request.json
        batch_id = int(resp.get('batch_id', "INVALID"))
        vouchers = resp.get( "vouchers", [])
    except:
        return {"status" : "error", "reason" : "Invalid data supplied" }


    try:
        batch = routesServices.reset_batch(batch_id, vouchers)
        return { "status" : "success", "batch" : routesServices.getBatchAsJSON(batch) }
    except ValueError as e:
        logger.error(f"Batch {batch_id} not found - {e}")
        return {"status" : "error", "reason" : "Batch not found" }


@admin_bp.route("/print_batch", methods=['POST'])
@set_headers
@roles_required([constants.VoucherManager])
def print_batch():

    try:
        resp = request.json
        batch_id = int(resp.get('batch_id', "INVALID"))
        vouchers = resp.get( "vouchers", [])

    except:
        return {"status" : "error", "reason" : "Invalid data supplied" }

    try:
        batch_html, hotel_name = routesServices.print_batch(batch_id, vouchers)
        title = f"BAVouchers - {hotel_name} - Batch {batch_id}"
        return { "status" : "success", "batch_html" : batch_html, "title": title }
    except ValueError as e:
        logger.error(f"Batch {batch_id} not found - {e}")
        return {"status" : "error", "reason" : "Batch not found" }


@admin_bp.route("/getVoucher/<string:voucher_id>")
@set_headers
@api_key_required_if_not_logged_in()
@roles_required([constants.VoucherManager, constants.VoucherActivator, constants.VoucherConsumer])
def get_voucher(voucher_id):

    voucher_id = escape(voucher_id)
    if len(voucher_id) > 10:
        return {"status" : "error", "reason" : "Voucher not found" }

    try:
        voucher = routesServices.getVoucher(voucher_id)

        # What is this user able to do with it?
        rooms_available = True
        can_activate = False
        can_use = False
        if current_user.has_role(constants.VoucherActivator) and voucher.status == constants.VoucherStatus.PRINTED.value:
            can_activate = True
        if current_user.has_role(constants.VoucherConsumer) and voucher.status == constants.VoucherStatus.ACTIVATED.value:
            can_use = True
            rooms_available = True
            if not routesServices.areRoomsAvailableForVoucher(voucher):
                rooms_available = False
    except ValueError as e:
        logger.error(f"Voucher {voucher_id} not found - {e}")
        return { 'status': "error",
                'reason': str(e)}
        
    # All ok
    return { "status" : "OK",
             "voucher_status" : voucher.status,
             "can_activate" : can_activate,
             "can_use" : can_use,
             "has_expired" : voucher.has_expired(),
             "rooms_available" : rooms_available,
    }

@admin_bp.route("/updateVoucher", methods=["POST"])
@set_headers
@csrf.exempt
@api_key_required_if_not_logged_in()
@roles_required([constants.VoucherActivator, constants.VoucherConsumer])
def update_voucher():

    voucher_id = request.form.get('voucher_id', "INVALID")
    voucher_id = escape(voucher_id.strip())
    if len(voucher_id) > 10:
        return {"status" : "error", "reason" : "Voucher not found" }

    try:
        voucher = routesServices.getVoucher(voucher_id)

        # What is this user able to do with it?
        if voucher.has_expired() and voucher.status != constants.VoucherStatus.ACTIVATED.value:
            raise ValueError("Voucher has expired")
        if voucher.status == constants.VoucherStatus.ISSUED:
            raise ValueError("Voucher has not been printed yet")
        if voucher.status == constants.VoucherStatus.PRINTED and not current_user.has_role(constants.VoucherActivator):
            raise ValueError("You are not allowed to activate this voucher")
        if voucher.status == constants.VoucherStatus.ACTIVATED and not current_user.has_role(constants.VoucherConsumer):
            raise ValueError("You are not allowed to use this voucher")

        message = routesServices.updateVoucherStatus(voucher_id)
    except ValueError as e:
        logger.error(f"Unable to update {voucher_id} - {e}")
        message = str(e)
        

    return { "status" : "OK",
             "message" : message
    }

@admin_bp.route("/refresh_messages")
@set_headers
@roles_required([constants.VoucherManager, constants.RoomManager])
def refresh_messages():
    messages = messageServices.getMessagesByDay(current_user)
    messageServices.markMessagesAsRead(current_user)

    return { "status" : "OK",
             "messages" : messages,
             "current_user_name" : current_user.name,
    }


@admin_bp.route("/get_token")
@set_headers
@roles_required([constants.VoucherActivator, constants.VoucherConsumer])
def get_token():

    api_key = routesServices.getApiKey()
    resp = Response({"status" : "OK"})
    resp.headers['x-api-key'] = api_key
    return resp
    return { "token" : api_key }



""" This is test and development code only """
@admin_bp.route("/resetData", methods=["POST"])
@roles_required([constants.DashboardAdmin])
def resetData():

    routesServices.resetData()
    return "OK"