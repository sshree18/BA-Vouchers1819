import arrow
from flask import render_template, redirect, url_for, flash, request, session
from flask import current_app as app
from flask_login import current_user

from app.constants import (
    RoomManager, VoucherManager
)
from . import messageServices
from app.roles import roles_required
from app.utils import logger, set_headers

from app.admin.forms import ( MessageForm)

from app.admin import admin_bp

@admin_bp.route("/viewMessages", methods=['GET'])
@roles_required([RoomManager, VoucherManager])
def viewMessages():

    messageForm = MessageForm(request.form)

    context = {
        "messageForm" : messageForm
    }

    return render_template("admin/messages.html", user=current_user, **context)

@admin_bp.route("/sendMessage", methods=['POST'])
@set_headers
@roles_required([VoucherManager, RoomManager])
def sendMessage():

    messageForm = MessageForm(request.form)
    if messageForm.validate_on_submit():
        message_text = messageForm.message_text.data
        if message_text.strip() != "":
            messageServices.sendMessage( current_user, message_text)
    else:
        if len(messageForm.message_text.errors):
            flash("Message must be between 1 and 300 characters in length")

    return redirect(url_for('.viewMessages'))

