from app import db
from app.models import ( VoucherArchive )

def generateVoucherArchiveReport( startDate ):

    # Get all vouchers created on the start date
    vouchers = VoucherArchive.query.filter(db.func.date(VoucherArchive.created_at) == startDate).all()

    # Create csv based on voucerh archive
    csv = "ID,Voucher ID,Hotel name,Batch ID,Status,Stage Expiry,Issue Type,Issued By,Issued At,Printed By,Printed At,Activated By,Activated At,Used By,Used At,Created At\n"
    for voucher in vouchers:
        csv += f"{voucher.id},{voucher.voucher_id},{voucher.hotel_name},{voucher.batch_id},{voucher.status},{voucher.stage_expiry},{voucher.issue_type},{voucher.issued_by},{voucher.issued_at},{voucher.printed_by},{voucher.printed_at},{voucher.activated_by},{voucher.activated_at},{voucher.used_by},{voucher.used_at},{voucher.created_at}\n"

    return csv