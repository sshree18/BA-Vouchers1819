import arrow
from flask import render_template, redirect, url_for, flash, request, session
from flask import current_app as app
from flask_login import current_user

from app.constants import (
    DashboardAdmin,
)
from . import userManagementServices
from app.roles import roles_required
from app.utils import logger, set_headers

from app.auth import authUtils

from app import constants
from app import db
from app.models import User

from app import utils
from app import userUtils

from app.admin.forms import ( AddUserForm, UpdateUserDetailsForm)

from app.admin import admin_bp


#------------------------------------------------------
# Add and onboard admin  users functions
#------------------------------------------------------



@admin_bp.route("/manageUsers", methods=['GET', 'POST'])
@set_headers
@roles_required([DashboardAdmin])
def manage_users():

    search = request.args.get('search', "")

    users = userManagementServices.getUsers( search )

    context = {
        "users" : users,
        "search" : search
    }
    return render_template("admin/manageUsers.html", user=current_user, **context)


@admin_bp.route("/addUser", methods=['GET', 'POST'])
@set_headers
@roles_required([DashboardAdmin])
def addUser():
    adminRoles = userManagementServices.getAdminRoles()

    adminRoles = [val for val in adminRoles]

    # Only system admins can set other system admins
    if not current_user.has_role( constants.SystemAdmin ):
        adminRoles = [val for val in adminRoles if val.name != constants.SystemAdmin]

    form = AddUserForm(adminRoles)
    if form.validate_on_submit():
        try:
            # Filter the roles to only include the ones that were selected
            roles = [r for r in adminRoles if r.name in form.roles.data]

            userManagementServices.createAdminUser(current_user, form.name.data, form.login_id.data, roles)

            return redirect(url_for('.manage_users'))
        except Exception as e:
            flash(str(e))
            logger.error( "Error adding admin user: " + str(e) )

    return render_template("admin/addUser.html", user=current_user, form=form)

@admin_bp.route("/editUser/<user_id>", methods=['GET', 'POST'])
@set_headers
@roles_required([DashboardAdmin])
def editUser(user_id):
    user = authUtils.getUserById(user_id)
    adminRoles = userManagementServices.getAdminRoles()

    # Only system admins can set other system admins
    if not current_user.has_role( constants.SystemAdmin ):
        adminRoles = [val for val in adminRoles if val.name != constants.SystemAdmin]

    user_roles = [x.name for x in user.roles]
    form = UpdateUserDetailsForm(adminRoles)
    if form.validate_on_submit():
        try:
            # Filter the roles to only include the ones that were selected
            roles = [r for r in adminRoles if r.name in form.roles.data]
            
            userManagementServices.updateUser(current_user, user_id, roles, form.resetPassword.data, form.resetMFA.data)

            flash("User updated", "success")
            return redirect(url_for('.manage_users'))
        except Exception as e:
            flash(str(e))
            logger.error( "Error editing admin user: " + str(e) )
    else:
        form.roles.data = user_roles

    context = {
        "user_name" : user.name,
        "login_id": user.login_id,
        "form" : form,
    }


    return render_template("admin/editUser.html", user=current_user, **context)
        

@admin_bp.route("/deleteUser/<user_id>", methods=['POST'])
@set_headers
@roles_required([DashboardAdmin])
def deleteUser(user_id):
    try:
        userManagementServices.deleteUser(current_user, user_id)
        flash( "User deleted", "success" )

        return "OK"
    except Exception as e:
        flash( str(e) )
        logger.error( "Error deleting user: " + str(e) )
        return "Error"



@admin_bp.route("/unlockUser/<user_id>", methods=['POST'])
@set_headers
@roles_required([DashboardAdmin])
def unlockUser(user_id):
    try:
        authUtils.unlockUser(user_id)
        flash( "User unlocked", "success" )

        return "OK"
    except Exception as e:
        flash( str(e) )
        logger.error( "Error unlocking user: " + str(e) )
        return "Error"


