import arrow
from flask import render_template, Response, flash, request, session
from flask import current_app as app
from flask_login import current_user

from app.constants import (
    VoucherManager,
)
from . import reportServices
from app.roles import roles_required
from app.utils import logger, set_headers

from app import db
from app.models import VoucherArchive
from app.admin.forms import ( VoucherArchiveReportForm )

from app.admin import admin_bp


#------------------------------------------------------
# Report functions
#------------------------------------------------------

@admin_bp.route("/generateReport", methods=['GET', 'POST'])
@set_headers
@roles_required([VoucherManager])
def generateReport():

    startDate = arrow.now().datetime
    form = VoucherArchiveReportForm( startDate=startDate)
    if form.validate_on_submit():
        try:
            startDate = form.startDate.data
            reportData = reportServices.generateVoucherArchiveReport(startDate)

            # download file
            filename = f"voucher_archive_report_{startDate}.csv"

            return Response(
                reportData,
                mimetype="text/csv",
                headers={"Content-disposition":
                        f"attachment; filename={filename}"})


        except Exception as e:
            flash(str(e))
            logger.error("Error generating report - " + str(e))

    context = {
        "form" : form,
        "user" : current_user, 
    }

    return render_template('admin/voucherArchiveReport.html', **context)
