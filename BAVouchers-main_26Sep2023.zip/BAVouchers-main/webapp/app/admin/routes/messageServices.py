import arrow

from app import db
from app.models import Messages
from app import templateFilters

def getMessagesByDay(current_user):
    lastDate = None
    all_messages = Messages.query.order_by(Messages.sent_at.desc()).all()
    messages = []

    currentMessage = {}
    for message in all_messages:
        messageDate = arrow.get(message.sent_at).date()
        if messageDate != lastDate:
            currentMessage = {"date": templateFilters.format_date(messageDate), "messages": []}
            messages.append(currentMessage)
            lastDate = messageDate

        # Append current message
        newMessage = { "message_id": message.message_id, "message_lines" : message.message.split( "\n" ), "is_read" : message.is_read, "sent_at": templateFilters.format_humanized(message.sent_at), "read_at": message.read_at  }
        newMessage["sent_by"] = message.sent_by
        newMessage["sender"] = message.sent_by

        currentMessage["messages"].append( newMessage )
    
    return messages

def sendMessage( from_user, message_text ):

    """ Adds a message for a candidate sent by either a candidate or a BA user """
    message = Messages( sent_by=from_user.name, message=message_text )

    db.session.add( message )
    db.session.commit()

    return message.message_id

def getUnreadMessageCount( current_user ):
    lastRead = current_user.last_read_message
    if lastRead == None:
        lastRead = arrow.get( "1970-01-01" ).datetime
    messages = Messages.query.filter(Messages.sent_at >= lastRead).all()

    return len(messages)

def markMessagesAsRead(current_user ):
    current_user.last_read_message = arrow.now().utcnow().datetime

    db.session.commit()

