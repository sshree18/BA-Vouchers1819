import arrow

from flask import flash

from app import awsfunctions
from app import db
from app import utils
from app.models import ( Role, User )
from app.auth import authUtils
from app import constants

def getUsers( search ):
    # users = User.query.filter(User.name != constants.BA_USER).all()
    users = User.query.all()
    return users

def getAdminRoles():
    """ Returns a list of admin roles """
    roles = Role.query.order_by('name').all()
    unique_roles = set()
    role_list = [unique_roles.add(role.name) or role for role in roles if role.name not in unique_roles]
    return role_list

def createAdminUser(current_user, name, login_id, roles):
    """ Creates a new admin user
    If the email address already exists an error is raised

    :param name: The name of the admin user
    :param login_id: The login_id of the admin user
    :param roles: The roles the admin user is requesting
    """

    # generate random password
    password = utils.generatePassword()
    password_expiry = arrow.utcnow().shift(days=+90).date()
    user = User.query.filter_by(login_id=login_id).first()
    if user is None:

        user = User(login_id=login_id, name=name, password=password, roles=roles,
                    password_expires=password_expiry)
        db.session.add(user)
        db.session.commit()

        #sending_from = userUtil.sendingFromEmail(user)

        params = {"name": name,
                  "password": password,
                  "login_id": login_id,
                  }
        
        flash(f"User created - generated temporary password {password}", "success")

        #awsfunctions.sendEmail("onboard_admin", "User account created", params, [login_id], sending_from)

        details = { "name" : name, "login_id": login_id, "roles" :roles}
        awsfunctions.addAuditEntry(current_user, 'user_created', details)

    else:
        raise ValueError(f"User with login id {login_id} already exists ")


def updateUser(current_user, user_id, roles, resetPassword, resetMFA):
    """ Updates a user
    If resetPassword is True then a new password is generated and an email is sent to the user

    :param user_id: The id of the user to update
    :param roles: The roles the user is requesting
    :param resetPassword: True if the user should be given a new password
    :param resetMFA: True if the user should be given a new MFA device
    """
    user = User.query.filter_by(user_id=user_id).first()
    if user == None:
        flash("No user found")
        return

    # reset roles and add new ones

    user.roles = roles

    # Check for reset password
    if resetPassword:
        password = utils.generatePassword()
        password_expiry = arrow.utcnow().shift(days=+90).date()
        user.password = password
        user.password_expires = password_expiry

        # authUtils.generate_password_reset_email(user)
        flash(f"User updated - generated temporary password {password}", "success")

    db.session.commit()

    if resetMFA:
        authUtils.resetMFA(user)

    role_names = [r.name for r in roles]
    details = { "login_id" : user.login_id, "roles" :role_names}
    awsfunctions.addAuditEntry(current_user, 'user_details_updated', details)


def deleteUser(current_user, user_id):
    """ Deletes a user IF they are not themselves
    :param current_user: The user who is deleting the user
    :param user_id: The id of the user to delete
    """
    user = User.query.filter_by(user_id=user_id).first()
    if user is None:
        raise ValueError(f"User with id {user_id} not found")
    if user.user_id == current_user.user_id:
        raise ValueError(f"You cannot delete yourself")

    login_id = user.login_id

    db.session.delete(user)
    db.session.commit()

    details = { "login_id" : login_id}
    awsfunctions.addAuditEntry(current_user, 'user_details_updated', details)

