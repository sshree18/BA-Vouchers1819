import arrow

from flask import flash
from flask_login import current_user

from app import db, utils
from app.models import ( Role, Hotel )
from app import awsfunctions


def getHotels( ):
    hotels = Hotel.query.order_by(Hotel.display_order, Hotel.name).all()
    return hotels

def getHotel( hotel_id):
    hotel = Hotel.query.filter_by(id=hotel_id).first()
    if hotel == None:
        flash("No hotel found")
        return None

    return hotel

def addhotel(form_data):
    hotel = Hotel(
        name = form_data.name.data,
        address = form_data.address.data,
        display_order = form_data.display_order.data,
        checkin_time = form_data.checkin_time.data,
        checkout_time = form_data.checkout_time.data,
        breakfast_times = form_data.breakfast_times.data,
        dinner_times = form_data.dinner_times.data,
        additional_info = form_data.additional_info.data,
        default_room_allocation = form_data.default_room_allocation.data,
        bau_safetystock_rate = form_data.bau_safetystock_rate.data,
        dis_safetystock_rate = form_data.dis_safetystock_rate.data,
        bau_printed_expiry = form_data.bau_printed_expiry.data,
        dis_printed_expiry = form_data.dis_printed_expiry.data,
        bau_activated_expiry = form_data.bau_activated_expiry.data,
        dis_activated_expiry = form_data.dis_activated_expiry.data,
    )
    db.session.add(hotel)
    db.session.commit()

    details = { "name" : hotel.name, "address": hotel.address, "default_allocation" : hotel.default_room_allocation}
    awsfunctions.addAuditEntry(current_user, 'hotel_created', details)

def updatehotel(hotel_id, form_data):
    hotel = Hotel.query.filter_by(id=hotel_id).first()
    if hotel == None:
        flash("No hotel found")
        return

    hotel.name = form_data.name.data
    hotel.address = form_data.address.data
    hotel.display_order = form_data.display_order.data
    hotel.checkin_time = form_data.checkin_time.data
    hotel.checkout_time = form_data.checkout_time.data
    hotel.breakfast_times = form_data.breakfast_times.data
    hotel.dinner_times = form_data.dinner_times.data
    hotel.additional_info = form_data.additional_info.data

    hotel.default_room_allocation = form_data.default_room_allocation.data
    hotel.bau_safetystock_rate = form_data.bau_safetystock_rate.data
    hotel.dis_safetystock_rate = form_data.dis_safetystock_rate.data
    hotel.bau_printed_expiry = form_data.bau_printed_expiry.data
    hotel.dis_printed_expiry = form_data.dis_printed_expiry.data
    hotel.bau_activated_expiry = form_data.bau_activated_expiry.data
    hotel.dis_activated_expiry = form_data.dis_activated_expiry.data

    db.session.commit()

    details = { "address": hotel.address, "default_allocation" : hotel.default_room_allocation}
    awsfunctions.addAuditEntry(current_user, 'hotel_updated', details)


def deleteHotel(hotel_id):
    """ Deletes a user IF they are not themselves
    :param current_user: The user who is deleting the user
    :param user_id: The id of the user to delete
    """
    hotel = Hotel.query.filter_by(id=hotel_id).first()
    hotel_name = hotel.name
    if hotel is None:
        raise ValueError(f"Hotel with id {hotel_id} not found")

    db.session.delete(hotel)
    db.session.commit()

    details = { "hotel_name": hotel_name }
    awsfunctions.addAuditEntry(current_user, 'hotel_deleted', details)

