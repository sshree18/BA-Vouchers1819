from functools import wraps

from flask import session, request, redirect, url_for, request, flash
from flask_login import current_user, logout_user, login_user
from app import constants
from app.IPWhitelistCache import ipWhitelistCache

from app import authClient
from app import userUtils

def checkIPWhitelisting():
    return ipWhitelistCache.is_users_ip_whitelisted()

def api_key_required_if_not_logged_in():
    def _api_key_required_if_not_logged_in(f):
        @wraps(f)
        def decorated_view(*args, **kwargs):
            # If ensure their IP is in the whitelist
            if checkIPWhitelisting() == False:
                flash( "Your IP address is not whitelisted for this service. Please contact your administrator." )
                return  redirect( url_for('auth.logout') )


            # get x-api-key from header
            api_key = request.headers.get('x-api-key', None)
            if api_key == None:
                return f(*args, **kwargs)
            
            # get user by API Key
            user = userUtils.getUserByAPIKey(api_key)
            if user == None:
                return f(*args, **kwargs)
            
            # login user
            login_user(user)
            session["is_mobile"] = "true"

            return f(*args, **kwargs)
        return decorated_view
    return _api_key_required_if_not_logged_in


def roles_required(roles: list, require_all=False):
    def _roles_required(f):
        @wraps(f)
        def decorated_view(*args, **kwargs):

            # Ensure their IP is in the whitelist
            if checkIPWhitelisting() == False:
                flash( "Your IP address is not whitelisted for this service. Please contact your administrator." )
                return  redirect( url_for('auth.logout') )

            if len(roles) == 0:
                raise ValueError('Empty list used when requiring a role.')
            
            # Are we a BA user?
            if not authClient.is_authenticated() and not current_user.is_authenticated:
                session['next'] = request.url
                if 'mobile' in request.headers:
                    session["is_mobile"] = "true"
                return  redirect( url_for('auth.login') )
            
            if "session_id" not in session or session["session_id"] != current_user.session_id:
                if "is_mobile" not in session:
                    return  redirect( url_for('auth.logout') )
            if require_all and not all(current_user.has_role(role) for role in roles):
                flash( "You do not have permission to access this page.")
                return  redirect( url_for('auth.logout') )
            elif not require_all and not any(current_user.has_role(role) for role in roles):
                flash( "You do not have permission to access this page.")
                return  redirect( url_for('auth.logout') )
            return f(*args, **kwargs)
        return decorated_view
    return _roles_required

